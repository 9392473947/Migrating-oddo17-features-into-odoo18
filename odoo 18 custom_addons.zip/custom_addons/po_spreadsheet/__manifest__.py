{
    'name' : 'Purchase order spreadsheet stotz',
    'version' : '2.0',
    'author': 'Nivetha',
    'summary': 'purchase order spreadsheet',
    'sequence': 10,
    'depends': ['purchase','base','mrp','mrp_subcontracting_purchase','stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/po_spreadsheet_add.xml',

       ],
#
# 'assets': {
#         'web.assets_backend': [
#             'po_spreadsheet/static/src/xml/po_spreadsheet_view.xml'
#             ],
# },

    'installable': True,

    'module_type': 'official',
    'license': 'LGPL-3'
}