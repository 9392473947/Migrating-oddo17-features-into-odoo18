from odoo import models, fields, api, _
import io
import pdfplumber
import base64
from odoo.exceptions import UserError, ValidationError
from openai import OpenAI,NotFoundError,RateLimitError
import json


class StockPickingOcrOpenai(models.Model):
    _inherit = 'stock.picking'

    upload_ocr_pdf = fields.Binary('PDF For OCR')
    file_name = fields.Char('File Name')

    def ocr_with_openai(self):
        try:
            if not self.upload_ocr_pdf:
                raise UserError("No file uploaded.")
            file_content = base64.b64decode(self.upload_ocr_pdf)
            # Check if the file starts with the PDF header "%PDF"
            if not file_content.startswith(b'%PDF'):
                raise ValidationError("The uploaded file is not a PDF. Please upload a PDF file.")

            pdf_stream = io.BytesIO(file_content)
            json_product_details = []
            for product_line in self.move_ids_without_package:
                json_product_details.append({
                    "product_name": product_line.product_id.name,
                    "quantity": product_line.product_uom_qty,
                    # "unit_price": product_line.price_unit,
                    # "total_price": product_line.price_subtotal
                })

            purchase_order_json_format = {
                "customer_details": {
                    "customer_name": self.company_id.name,
                    "vendor_name": self.partner_id.name,
                    "receipt_number": self.name,
                },
                "products": json_product_details
            }
            lines = []
            # Open the PDF with pdfplumber
            with pdfplumber.open(pdf_stream) as pdf:
                ss = ''
                for page in pdf.pages:
                    ss += page.extract_text()
                    lines.extend(page.extract_text().split('\n'))
                json_data_format = """{
                                        "customer_details": {
                                        "customer_name": "",
                                        "vendor_name": "",
                                        "purchase_order_number": ""
                                        "total_amount": ""
                                        "total_tax": ""
                                      },
                                      "products": [
                                        {
                                          "product_name": "",
                                          "quantity": ,
                                          "unit_price": ,
                                          "total_price":
                                        },
                                  ]
                                }"""

                get_api_key = self.env['ir.config_parameter'].sudo().get_param('ocr_pdf_comparing.openai_api')
                if get_api_key:
                    client = OpenAI(api_key=get_api_key)
                else:
                    raise ValidationError('Please add the Api key in setting.')
                "For get the data from the PDF TEXT"
                stream = client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "user", "content": f"Please summarize the text: {ss}"},
                        {"role": "user",
                         "content": "From the summarized text, extract the following product details exactly as they appear in the text:\n"
                                    "1. Product Name\n(exact product name only)"
                                    "2. Quantity\n"
                                    "3. Unit price (as a number, without currency symbols)\n"
                                    "4. Total price (as a number, without currency symbols)"},
                        {"role": "user", "content": "Also, extract the following from the text:\n"
                                                    "1. Customer Name\n (Exact name of the customer)"
                                                    "2. Vendor Name\n (Exact name of the vendor)"
                                                    "3. Order Number (means purchase order number )"
                                                    "4. Total Amount (give total amount in correct extract same format as product unit price)"
                                                    "5. Total Tax (give total Tax in correct extract same format as product unit price)"},
                        {"role": "user", "content": f"Please follow this JSON format:\n{json_data_format}"},
                        {"role": "user", "content": "Please give only JSON data in your response."},
                        {"role": "user",
                         "content": "Ensure that the data matches exactly as it appears in the text, with no calculations or changes. The numbers should be formatted as simple floating-point numbers (e.g., 3.23) without any currency symbols."},
                        # {'role': 'user',
                        #  'content': f"""Compare the following JSON data {purchase_order_json_format} with the given purchase order JSON format. The output should include the matching values, including all product details, vendor name, and customer name. The result should be formatted as JSON, with the matching values presented between the original JSON and the new JSON data. Insert the text "can_break" between the two JSON sections to facilitate later splitting."""}
                    ],
                    stream=True,
                )
                "For getting from the compared data"
                # stream = client.chat.completions.create(
                #     model="gpt-4o",
                #     messages=[
                #         {"role": "user",
                #          "content": f"In the provided {ss}, please check if all the details in the following JSON are present:\n"
                #                     f"{purchase_order_json_format}\n"
                #                     "For each detail that is present, return the JSON format with only those matching details."},
                #         {"role": "user",
                #          "content": "I want three separate JSON outputs:\n"
                #                     "1. The first JSON should include all matching data.\n"
                #                     "2. The second JSON should include all non-matching data from the provided JSON.\n"
                #                     "3. The third JSON should include all non-matching data found in the text.\n"
                #                     f"4. Extract all the details from the text in the same format as the provided JSON (order number means purchase order number) follow this json: {json_data_format} get data from the text.\n"
                #                     "Separate these JSON outputs with the text 'can_break' so that I can easily split them later."},
                #         {"role": "user", "content": "Please give only JSON data in your response."},
                #         {"role": "user",
                #          "content": "Ensure that the data matches exactly as it appears in the text, with no calculations or changes. The numbers should be formatted as simple floating-point numbers (e.g., 3.23) without any currency symbols."},
                #         {"role": "user",
                #          "content": "Please also check that you giving the exact answer what am asking for."},
                #
                #     ],
                #     stream=True,
                # )

                "Common for this"
                # Initialize an empty string to capture the response
                response_text = ""
                # Process the streaming response
                for chunk in stream:
                    if chunk.choices[0].delta.content is not None:
                        response_text += chunk.choices[0].delta.content
                # Remove the JSON markers
                json_data = response_text.replace("```json", "").replace("```", "").strip()
                json_dict = json.loads(json_data)
                aligned_text = ss.replace('\n', '<br/>')
                report_text_for_html = f"<h3>{aligned_text}</h3>"
                if json_dict:
                    view_id = self.env.ref('ocr_pdf_comparing.pdf_compare_view_form').id

                    return {
                        'type': 'ir.actions.act_window',
                        'name': _('Report Update'),
                        'view_mode': 'form',
                        'res_model': 'pdf.compare',
                        'target': 'new',
                        'views': [[view_id, 'form']],
                        'context': {'default_updates': report_text_for_html, 'default_openai_output': json_data,
                                    'default_stock_picking_id': self.id, 'default_report_view': self.upload_ocr_pdf}
                    }
        except NotFoundError as e:
            error_message = e.message
            if 'you do not have access to it' in error_message:
                raise UserError('User do not have access to it.')
            else:
                raise UserError(error_message)
        except RateLimitError as e:
            error_message = e.message
            if 'exceeded your current quota' in error_message:
                raise UserError('You exceeded your current quota, please check your plan and billing details.')
            else:
                raise UserError(error_message)
        except Exception as e:
            raise UserError(f"An unexpected error occurred: {str(e)}")