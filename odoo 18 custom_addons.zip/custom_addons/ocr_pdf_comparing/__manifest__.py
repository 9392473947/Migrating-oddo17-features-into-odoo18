{
    'name': 'PDF Compare',
    'category': 'PDF Compare',
    'description': """ """,
    'depends': ['purchase', 'stock', 'base_setup'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/pdf_compare.xml',
        'views/purchase_order.xml',
        'views/stock_picking_ocr.xml',
        'views/res_config_settings.xml',
    ],
    "application": True,
    'assets': {
        'web.assets_backend': [

        ],
    },
}
