{
    'name': 'Contact Approval',
    'category': 'Contact Approval',
    'description': """ """,
    'depends': ['base', 'crm'],
    'data': [
        "security/contact_approval.xml",
        "views/res_partner.xml",
        ],

    'license': 'OEEL-1',
    "application": True,
}
