from odoo import api,models,fields

class ProductChannel(models.Model):
    _name = 'product.channel'

    name = fields.Char(string="Channel")
    code = fields.Char(string="Channel Code")


class ProductJet(models.Model):
    _name = 'product.jet'

    name = fields.Char(string="Jets")
    code = fields.Char(string="Jet Code")