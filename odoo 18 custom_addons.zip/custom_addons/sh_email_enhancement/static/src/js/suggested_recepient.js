///* @odoo-module */

import { SuggestedRecipient } from "@mail/core/web/suggested_recipient";
////import { SuggestedRecipient } from "@mail/core/web/thread_service_patch";
import { patch } from "@web/core/utils/patch";
//import { ThreadService, threadService } from "@mail/core/common/thread_service";
import { Thread } from "@mail/core/common/thread_model";
//import { parseEmail } from "@mail/js/utils";
import { parseEmail } from "@mail/utils/common/format";

let nextId = 1;
patch(Thread.prototype, {
async insertSuggestedRecipients(thread, dataList) {
        const recipients = [];
        for (const data of dataList) {
            const [partner_id, emailInfo, lang, reason, defaultCreateValues] = data;
            let [name, email] = emailInfo ? parseEmail(emailInfo) : [];
            if ((!name || name === email) && defaultCreateValues?.name) {
                name = defaultCreateValues.name;
            }
            recipients.push({
                id: nextId++,
                name,
                email,
                lang,
                reason,
                persona: partner_id ? { type: "partner", id: partner_id } : false,
                checked: false,
                defaultCreateValues,
            });
        }
        thread.suggestedRecipients = recipients;
    }
})

//patch(SuggestedRecipient.prototype,{
//
//    setup() {
//        super.setup();
//        this.props.recipient.checked = false;
//    }
//
//})

/* @odoo-module */

//import { patch } from '@web/core/utils/patch';
//import { parseEmail } from '@web/core/utils/strings'; // Odoo 18's parseEmail equivalent
//const mail_thread = mail.components.Thread; //access thread component from mail module
//
//let nextId = 1;
//
//patch(mail_thread, 'mail.Thread', {  // Replace 'your_module'
//    async insertSuggestedRecipients(dataList) { // No 'thread' argument in Odoo 18
//        const recipients = [];
//        for (const data of dataList) {
//            const [partner_id, emailInfo, lang, reason, defaultCreateValues] = data;
//            let [name, email] = emailInfo ? parseEmail(emailInfo) : []; // Use Odoo's parseEmail
//            if ((!name || name === email) && defaultCreateValues?.name) {
//                name = defaultCreateValues.name;
//            }
//            recipients.push({
//                id: nextId++,
//                name,
//                email,
//                lang,
//                reason,
//                persona: partner_id ? { type: "partner", id: partner_id } : false,
//                checked: false,
//                defaultCreateValues,
//            });
//        }
//        // In Odoo 18, suggested recipients are often managed on the mail.thread or mail.message
//        // itself or through a related field.  You'll likely need to adapt this part
//        // to how your module or the feature you're working with handles it.
//        this.suggestedRecipients = recipients; // Example: Setting it directly on the thread
//        // Or, if it's on mail.message
//        // this.env.model('mail.message').write([this.id], { suggested_recipients: recipients });
//    }
//});