from odoo import models, fields, api


class CompareValues(models.TransientModel):
    _name = 'compare.values'

    odoo_values = fields.Html('Values')
    report_values = fields.Html('Report Values')
    pdf_compare = fields.Many2one('pdf.compare')
