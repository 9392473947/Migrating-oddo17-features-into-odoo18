from odoo import models, fields, api,_
from odoo.exceptions import ValidationError
import base64


class ProjectProduct(models.Model):
    _inherit = 'project.project'
    field_service_product = fields.Many2one('product.product','Product')


class TaskFieldService(models.Model):
    _inherit='project.task'
    # milestone_id = fields.Many2one(
    #     'project.milestone',
    #     'Milestone',
    #     domain="[('project_id', '=', project_id)]",
    #     compute='_compute_milestone_id',
    #     readonly=False,
    #     store=True,
    #     tracking=True,
    #     index='btree_not_null',
    #     help="Deliver your services automatically when a milestone is reached by linking it to a sales order item.",
    #     copy=False
    # )

    # is_fsm = fields.Boolean('project_id.is_fsm',store=True)
    field_service_sequence = fields.Char(string='Service Id', readonly=True)
    # is_fsm = fields.Boolean(related='project_id.is_fsm', search='_search_is_fsm')
    field_service_product = fields.Many2one('product.template','Product')
    kilometer = fields.Float('Kilometers Travelled')
    # travelling_type = fields.Selection([('to','Travelling Time To'), ('back','Travelling Time Back'), ('break','Travelling Time Break'),
    # ('working_hours','Working Hours'),('working_break','Work Break')])
    is_training = fields.Boolean('Training')
    training_data_ids = fields.One2many('training.data', 'field_service_id')
    training_place = fields.Char('Place')
    training_datetime = fields.Datetime('Date')
    trainer = fields.Many2one('res.partner', 'Referent: Trainer/Field service engineer', )
    trainer_sign = fields.Binary('Signature')
    training_details = fields.Html('Training Detail')
    training_content = fields.Html('Training content:')

    @api.constrains('kilometer')
    def _check_kilometer(self):
        for record in self:
            if record.kilometer == 0 and record.is_fsm:
                raise ValidationError('Please Enter the Kilometers.')

    # @api.constrains('date_deadline', 'milestone_id')
    # def _check_deadline(self):
    #     for task in self:
    #         if task.milestone_id and task.date_deadline:
    #             print(task.milestone_id, task.date_deadline,'task')
    #             task_deadline = fields.Date.to_date(task.date_deadline)
    #             milestone_deadline = fields.Date.to_date(task.milestone_id.deadline)
    #             print(task_deadline,'task_deadline')
    #             print(milestone_deadline)
    #             print(task.name)
    #             if task_deadline and milestone_deadline:
    #
    #                 if task_deadline > milestone_deadline:
    #                     raise ValidationError('The task deadline cannot be greater than the milestone deadline.')

    # def create(self, vals_list):
    #     context = self.env.context
    #     print(context)
    #     for vals in vals_list:
    #         if context.get('fsm_mode', False) and vals.get('is_fsm', True):
    #             # print(context.get('fsm_mode'))
    #             # print(context.get('fsm_mode', False))
    #             # print(vals.get('is_fsm'))
    #             # print(vals.get('is_fsm', True))
    #             # print('iff')
    #             vals['field_service_sequence'] = self.env['ir.sequence'].next_by_code('service.task.new') or _('New')
    #     return super(TaskFieldService, self).create(vals_list)

    # @api.model
    # def create(self, vals_list):
    #     for vals in vals_list:
    #         if self.env.context.get('fsm_mode', False) and vals.get('is_fsm', True):
    #             vals['field_service_sequence'] = self.env['ir.sequence'].next_by_code('service.task.new') or _('New')
    #     return super(TaskFieldService, self).create(vals_list)

    @api.model_create_multi
    def create(self, vals_list):
        context = dict(self.env.context)
        print(vals_list,'vals_list')
        for vals in vals_list:
            print(vals,'vals')
            if context.get('fsm_mode', False) and vals.get('is_fsm', True):
                vals['field_service_sequence'] = self.env['ir.sequence'].next_by_code('service.task.new') or _('New')
        return super(TaskFieldService, self).create(vals_list)


    # def action_fsm_validate(self, stop_running_timers=False):
    #
    #    res = super(TaskFieldService,self).action_fsm_validate(stop_running_timers)
    #    print("okk")
    #    for rec in self:
    #        if rec.field_service_product and rec.kilometer:
    #            sale_order = rec.sale_order_id
    #            product = rec.field_service_product
    #            kilometer = rec.kilometer
    #            order_line = rec.sale_line_id.product_template_id
    #
    #
    #            if sale_order and product:
    #                order_line_vals = {
    #                    'order_id': sale_order.id,
    #                    'product_template_id': order_line.id,
    #                    'product_id': product.id,
    #                    'product_uom_qty': kilometer,
    #                    'price_unit': product.list_price,
    #                    'product_uom': product.uom_id.id,
    #                    'name': product.name,
    #                }
    #                print(order_line_vals)
    #                self.env['sale.order.line'].create(order_line_vals)
    #    return res

    def action_fsm_validate(self, stop_running_timers=False):
        res = super(TaskFieldService, self).action_fsm_validate(stop_running_timers)
        print("okk")
        for rec in self:
            project = rec.project_id
            product = project.field_service_product
            kilometer = rec.kilometer

            if product and kilometer:
                sale_order = rec.sale_order_id

                if sale_order:
                    order_line_vals = {
                        'order_id': sale_order.id,
                        'product_id': product.id,
                        'product_uom_qty': kilometer,
                        'price_unit': product.list_price,
                        'product_uom': product.uom_id.id,
                        'name': product.name,
                    }
                    print(order_line_vals)
                    self.env['sale.order.line'].create(order_line_vals)
        return res


class AccountTravel(models.Model):
    _inherit = 'account.analytic.line'

    travelling_type = fields.Selection([('to','Travelling Time To'), ('back','Travelling Time Back'), ('break','Travelling Time Break'),
    ('working_hours','Working Hours'),('working_break','Work Break')])



class ProjectTaskTravellingType(models.TransientModel):
    _inherit = 'project.task.create.timesheet'

    travelling_type = fields.Selection(
        [('to', 'Travelling Time To'), ('back', 'Travelling Time Back'), ('break', 'Travelling Time Break'),
         ('working_hours', 'Working Hours'), ('working_break', 'Work Break')])

    #
    # def save_timesheet(self):
    #     res = super(ProjectTaskTravellingType,self).save_timesheet()
    #     print(res)
    #     return res

    def save_timesheet(self):
        values = {
            'task_id': self.task_id.id,
            'project_id': self.task_id.project_id.id,
            'date': fields.Date.context_today(self),
            'name': self.description,
            'user_id': self.env.uid,
            'unit_amount': self.task_id._get_rounded_hours(self.time_spent * 60),
            'travelling_type': self.travelling_type,
        }
        self.task_id.user_timer_id.unlink()
        return self.env['account.analytic.line'].create(values)


class CustomAccountMoveMail(models.AbstractModel): #changed from TransientModel to AbstractModel
    _inherit = 'account.move.send'
    report_attached = fields.Boolean(string="Report Attached", default=False)


    @api.depends('mail_template_id')
    def _compute_mail_attachments_widget(self):
        for wizard in self:
            account_move_id = self.env['account.move'].browse(self.env.context.get('active_id'))
            sale_order = account_move_id.line_ids.sale_line_ids.order_id.id
            print('aaaaaaaaaa')
            tasks = self.env['project.task'].search([('sale_order_id', '=', sale_order), ('is_fsm', '=', True)])
            print(tasks, 'aaaaa')
            mail_attach = []

            for task in tasks:
                attachment_name = f"Field Service Report - {task.name}"

                # Check if attachment already exists
                existing_attachment = self.env['ir.attachment'].search([
                    ('res_model', '=', 'project.task'),
                    ('res_id', '=', task.id),
                    ('name', '=', attachment_name)
                ], limit=1)

                if existing_attachment:
                    print('existing attachment found')
                    mail_attach.append({
                        'id': existing_attachment.id,
                        'name': existing_attachment.name,
                        'mimetype': 'application/pdf',
                        'placeholder': False,
                        'protect_from_deletion': True
                    })
                else:
                    print('creating new attachment')
                    file, file_type = self.env['ir.actions.report']._render_qweb_pdf(res_ids=task.ids,
                                                                                     report_ref="industry_fsm_report.task_custom_report")
                    print(file)
                    attachment = self.env['ir.attachment'].create({
                        'name': attachment_name,
                        'datas': base64.b64encode(file),
                        'type': 'binary',
                        'mimetype': 'application/pdf',
                        'res_model': 'project.task',
                        'res_id': task.id,
                    })
                    mail_attach.append({
                        'id': attachment.id,
                        'name': attachment.name,
                        'mimetype': 'application/pdf',
                        'placeholder': False,
                        'protect_from_deletion': True
                    })

            print('dddddddddddd')
            if wizard.mode == 'invoice_single':
                manual_attachments_data = [x for x in wizard.mail_attachments_widget or [] if x.get('manual')]
                print('manual_attachments_data', manual_attachments_data)
                wizard.mail_attachments_widget = (
                        self._get_default_mail_attachments_widget(wizard.move_ids, wizard.mail_template_id)
                        + manual_attachments_data
                        + mail_attach
                )
                print('mail_attachments_widget', wizard.mail_attachments_widget)
            else:
                wizard.mail_attachments_widget = []

        return True
