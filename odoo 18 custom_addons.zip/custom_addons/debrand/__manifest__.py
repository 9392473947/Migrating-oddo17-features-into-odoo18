# -*- coding: utf-8 -*-
{
    'name': "Debrand",
    'depends': ['base', 'web'],
    'update_xml': ['update.xml'],
    'auto_install': True,
    'web': True,
    'installable': True,
    'application': True,
    'data': [
        'views/debrand.xml',
        ],
    'license': 'LGPL-3',
}
