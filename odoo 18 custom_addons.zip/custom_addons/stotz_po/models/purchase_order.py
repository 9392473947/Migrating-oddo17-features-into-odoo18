from odoo import fields,api,models
from odoo.exceptions import ValidationError

class PurchaseOrderProduct(models.Model):
    _inherit = 'purchase.order.line'


    length =fields.Float(string="Length")
    diameter = fields.Float(string="Diameter")


    @api.onchange('order_id.partner_id','length','diameter')
    def _compute_price_unit_and_date_planned_and_name(self):
        super(PurchaseOrderProduct,self)._compute_price_unit_and_date_planned_and_name()
        self._compute_line_prices()

    def _compute_line_prices(self):
        for order in self:
                if order.product_id and order.length and order.diameter and order.partner_id:
                    supplier_infos = self.env['product.supplierinfo'].search([
                        ('partner_id', '=', order.partner_id.id),
                        ('product_tmpl_id', '=', order.product_id.product_tmpl_id.id)
                    ])
                    price_found = False
                    for supplier_info in supplier_infos:
                        if self._is_within_range(supplier_info.length_range, order.length) and \
                                self._is_within_range(supplier_info.diameter_range, order.diameter):
                            order.price_unit = supplier_info.price
                            price_found = True
                            break
                    if not price_found:
                        raise ValidationError("No vendor pricelist for the entered length and diameter.")



    def _is_within_range(self, range_str, value):
        if range_str:
            try:
                min_val, max_val = map(float, range_str.split('-'))
                return min_val <= value <= max_val
            except ValueError:
                raise ValidationError("No vendor pricelist for the enetered length and diameter")
            return False


