from odoo import models,fields

class PartnerCustomBank(models.Model):
    _inherit = 'res.partner'




    receiving_bank = fields.Many2one('res.partner.bank',string="Receiving Bank",required=True)



