{
    'name': 'Worksheet Template',
    'category': 'Contact Approval',
    'description': """ """,
    'depends': ['worksheet', ],
    'data': [
        'views/work_sheet.xml'

    ],

    'license': 'OEEL-1',
    "application": True,
}
