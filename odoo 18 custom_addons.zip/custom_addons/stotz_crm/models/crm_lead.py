from odoo import models,fields

class CrmLeadInherit(models.Model):
    _inherit = 'crm.lead'

    recent_cc = fields.Char('Recent Cc')