from odoo import api, fields, models,_
import io
import base64

import logging
import json
_logger = logging.getLogger(__name__)




class PurchaseOrderSpreadsheet(models.Model):
    _name = 'purchase.order.spreadsheet'
    _description = 'Purchase Order Spreadsheet'

    name = fields.Char(string='Name', required=True)
    purchase_order_id = fields.Many2one('purchase.order', string='Purchase Order', required=True)
    spreadsheet_data = fields.Binary(string='Spreadsheet Data')
    filename = fields.Char(string='Filename')




class PurchaseOrderSpreadsheet(models.Model):
    _inherit = 'purchase.order'

    def action_open_spreadsheet(self):
        existing_document = self.env['documents.document'].search([
                ('name', '=', f'Purchase_Order_{self.name}.xlsx'),
                ('handler', '=', 'spreadsheet'),
            ('datas', '!=', False),
            ], limit=1)

        if existing_document:
            return {
                "type": "ir.actions.client",
                "tag": "action_open_spreadsheet",
                "params": {
                    "spreadsheet_id": existing_document.id,
                    "is_new_spreadsheet": True,
                },
            }


        spreadsheet_vals = {
            "name": f'Purchase_Order_{self.name}.xlsx',
            "datas": self._empty_spreadsheet_data_base64(),
            "handler": "spreadsheet",
        }
        spreadsheet = self.env['documents.document'].create(spreadsheet_vals)
        return {
            "type": "ir.actions.client",
            "tag": "action_open_spreadsheet",
            "params": {
                "spreadsheet_id": spreadsheet.id,
                "is_new_spreadsheet": True,
            },
        }

    def _empty_spreadsheet_data_base64(self):
        data = json.dumps(self._empty_spreadsheet_data())
        return base64.b64encode(data.encode())

    def _empty_spreadsheet_data(self):
        """Create an empty spreadsheet workbook.
        The sheet name should be the same for all users to allow consistent references
        in formulas. It is translated for the user creating the spreadsheet.
        """
        lang = self.env["res.lang"]._lang_get(self.env.user.lang)
        locale = lang._odoo_lang_to_spreadsheet_locale()

        # Main sheet with purchase order data
        main_sheet = {
            "id": "main_sheet",
            "name": _("Purchase Order"),
            "cells": {
                "A1": {"content": _("PO Name")},
                "B1": {"content": _("Partner")},
                "C1": {"content": _("Order Date")},
                "D1": {"content": _("Planned Date")},
                "A2": {"content": str(self.name)},
                "B2": {"content": str(self.partner_id.name)},
                "C2": {"content": str(self.date_order.strftime('%d-%m-%Y'))},
                "D2": {"content": str(self.date_planned.strftime('%d-%m-%Y'))},

            },
        }

        # Sheets for each order line
        sheets = [main_sheet]
        for index, line in enumerate(self.order_line, start=1):
            sheet = {
                "id": f"po_line_{index}",
                "name": f"Order Line {index}",
                "cells": {
                    "A1": {"content": _("Product")},
                    "B1": {"content": _("Quantity")},
                    "C1": {"content": _("Unit Price")},
                    "A2": {"content": str(line.product_id.display_name)},
                    "B2": {"content": str(line.product_qty)},
                    "C2": {"content": str(line.price_unit)},
                },
            }
            sheets.append(sheet)

        return {
            "version": 1,
            "sheets": sheets,
            "settings": {
                "locale": locale,
            },
            "revisionId": "START_REVISION",
        }

