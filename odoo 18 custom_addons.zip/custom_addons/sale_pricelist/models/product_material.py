from odoo import api,models,fields

class ProductMaterials(models.Model):
    _name = 'product.material'


    name = fields.Char(string="Name")
    code = fields.Char(string="Code")
    surcharge = fields.Integer(string="Surcharge per Mandrel")