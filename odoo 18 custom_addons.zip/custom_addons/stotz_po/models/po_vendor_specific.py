from odoo import fields,models,api
from odoo.exceptions import AccessError

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

from datetime import datetime


class PurchaseOrderInherit(models.Model):
    _inherit = 'purchase.order'


    require_confirmation_from_supplier = fields.Boolean(string="PO Confirmation Received")
    is_supplier = fields.Boolean(string="Supplier", compute="_compute_require_confirmation", store=True)

    reminder_sent = fields.Boolean(string="Reminder Sent", default=False)
    second_reminder_sent = fields.Boolean(string="Second Reminder Sent", default=False)


    def action_rfq_send(self):
        # Check if all order lines have a price
        products_without_price = []
        for line in self.order_line:
            if line.price_unit <= 0:
                products_without_price.append(line.product_id.name)

        if products_without_price:
            product_names = ', '.join(products_without_price)
            raise ValidationError(f"The following products do not have a price: {product_names}")

        # Call the original method
        return super(PurchaseOrderInherit, self).action_rfq_send()




    @api.depends('partner_id.need_confirmation_for_po')
    def _compute_require_confirmation(self):
        for order in self:
            if order.partner_id.need_confirmation_for_po == True:
                order.is_supplier =True
            else:
                order.is_supplier = False



    def action_check_confirmation(self):

        for record in self:
            record.require_confirmation_from_supplier = True

    @api.model_create_multi
    def send_confirmation_reminder_emails(self):
        today = fields.Date.today()
        for order in self.search([('is_supplier', '=', True), ('state', '=', 'purchase')]):
            order_date = fields.Date.to_date(order.date_approve)
            days_since_order = (today - order_date).days

            if not order.require_confirmation_from_supplier:
                if days_since_order == 4:
                    email_body = (f"Dear {order.partner_id.name},\n\n"
                                  f"This is a reminder to confirm the Purchase Order {order.name}.")
                    email_to = order.partner_id.email
                    self.send_email(email_body, email_to)
                    self.send_message_to_order(order, email_body)


                elif days_since_order ==5:
                    purchase_executive = order.create_uid  # The user who created the order
                    email_body = (f"Dear {purchase_executive.name},\n\n"
                                  f"The Purchase Order {order.name} has not been confirmed by the vendor {order.partner_id.name} even after a reminder was sent.")
                    email_to = purchase_executive.email
                    self.send_email(email_body, email_to)
                    self.send_message_to_user(purchase_executive, email_body)
                    self.send_message_to_order(order, email_body)
                    self.send_message_to_user(purchase_executive, email_body)

                    channel_id = self.env.ref('mail.channel_all_employees')


                    message = f"Dear {order.create_uid.name},This is to inform you that Reminder mail is send to the Purchase Order {order.name} but still not been confirmed by the vendor."
                    user_id = order.create_uid.id

                    channel_id.message_post(
                        author_id=user_id,
                        body=message,
                        message_type='notification',
                        subtype_xmlid='mail.mt_comment',
                    )

    def send_email(self, body, to):
        mail_values = {
            'subject': 'Purchase Order Confirmation Reminder',
            'body_html': body,
            'email_to': to,
        }
        self.env['mail.mail'].create(mail_values).send()


    def send_message_to_order(self, order, body):
        order.message_post(body=body, subject="Purchase Order Confirmation Reminder")


    def send_message_to_user(self, user, body):
        user.partner_id.message_post(body=body, subject="Purchase Order Confirmation Reminder")

    @api.model_create_multi
    def create(self, vals):
        current_user = self.env.user
        print("Current User:", current_user.name, "| ID:", current_user.id)
        if not self.env.user.has_group('stotz_po.purchase_order_admin'):
            raise AccessError("You are not allowed to create purchase orders.")

        return super(PurchaseOrderInherit, self).create(vals)

    def write(self, vals):

        if not self.env.user.has_group('stotz_po.purchase_order_admin'):
            raise AccessError("You are not allowed to modify purchase orders.")

        return super(PurchaseOrderInherit, self).write(vals)

    def unlink(self):
        if not self.env.user.has_group('stotz_po.purchase_order_admin'):
            raise AccessError("You are not allowed to delete purchase orders.")
        return super(PurchaseOrderInherit, self).unlink()

class PurchaseOrderSubcontractor(models.Model):
    _inherit = 'purchase.order'


    is_subcontracting = fields.Boolean(string="Subcontracted product", compute="_compute_is_subcontractor",store=True)


    @api.depends('product_id')
    def _compute_is_subcontractor(self):
        for order in self:
            is_subcontracting = False  # Default to False
            for line in order.order_line:
                for route in line.product_id.route_ids:
                    if route.name == "Resupply Subcontractor on Order":
                        is_subcontracting = True
                        break
                if is_subcontracting:
                    break  # Exit the loop once the condition is met
            order.is_subcontracting = is_subcontracting


    @api.depends('picking_ids', 'picking_ids.state')
    def _compute_receipt_status(self):
        super(PurchaseOrderSubcontractor, self)._compute_receipt_status()  # Call super method to compute receipt status

        for order in self:
            if order.receipt_status == 'partial':


                channel_id = self.env.ref('mail.channel_all_employees')

                for order in self:
                    if order.receipt_status == 'partial':
                        message = f"Dear {order.create_uid.name}, we partially received the Purchase Order {order.name}."
                        user_id = order.create_uid.id

                        channel_id.message_post(
                            author_id=user_id,
                            body=message,
                            message_type='notification',
                            subtype_xmlid='mail.mt_comment',
                        )

                purchase_executive = order.create_uid.email
                email_body = f"Dear {order.create_uid.name},\n\n" \
                             f"This is to inform you that we partially received the Purchase Order {order.name}."
                email_to =  purchase_executive# Update with the recipient email

                # Send email
                self.env['mail.mail'].create({
                    'subject': 'Partial Receipt Notification',
                    'body_html': email_body,
                    'email_to': email_to,
                }).send()


    def send_partially_received_emails(self):
        print("oiuytf")
        today = fields.Date.today()
        for order in self.search([('state', '=', 'purchase'),('receipt_status','=','partial')]):
            print(order.name)
            if order.effective_date:
                print(order.effective_date)
                print(order.receipt_status)
                receipt_date = fields.Date.to_date(order.effective_date)
                days_since_receipt = (today - receipt_date).days
                print(days_since_receipt)
                if days_since_receipt == 4:

                    email_body = (f"Dear {order.create_uid.email},\n\n"
                                  f"This is to inform you that the Purchase Order {order.name} is still partially received from {order.effective_date}.")
                    email_to = order.create_uid.email
                    self.send_email(email_body, email_to)


                    channel_id = self.env.ref('mail.channel_all_employees')
                    message = f"Dear {order.create_uid.name},  the Purchase Order {order.name} is still partially received from {order.effective_date}."
                    user_id = order.create_uid.id

                    channel_id.message_post(
                        author_id=user_id,
                        body=message,
                        message_type='notification',
                        subtype_xmlid='mail.mt_comment',
                    )

    def send_email(self, body, to):
        mail_values = {
            'subject': 'Purchase Order Confirmation Reminder',
            'body_html': body,
            'email_to': to,
        }
        self.env['mail.mail'].create(mail_values).send()

