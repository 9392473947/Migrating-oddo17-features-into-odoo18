from odoo import fields,models,api
from odoo.exceptions import ValidationError

class ProductTemplateInherit(models.Model):
    _inherit = 'product.supplierinfo'

    length_range = fields.Char(string="Length")
    diameter_range = fields.Char(string="Diameter")


    @api.onchange('length_range', 'diameter_range')
    def _check_range_format(self):
        for record in self:
            if record.length_range:
                if not self._validate_range_format(record.length_range):
                    raise ValidationError("Invalid length range format. Please use number-number format (e.g., 10-20)")
            if record.diameter_range :
                if not self._validate_range_format(record.diameter_range):
                    raise ValidationError("Invalid diameter range format. Please use number-number format (e.g., 5-15)")

    @staticmethod
    def _validate_range_format(value):
        """ Validate format of range fields """
        if not isinstance(value, str):
            return False
        parts = value.split('-')
        if len(parts) != 2:
            return False
        try:
            start = float(parts[0].strip())
            end = float(parts[1].strip())
            if start >= end:
                return False
        except ValueError:
            return False
        return True
