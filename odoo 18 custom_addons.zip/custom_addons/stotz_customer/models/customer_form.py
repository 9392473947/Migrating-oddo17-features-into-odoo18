from odoo import fields,models,api
from datetime import date
import re


class ResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    # need_confirmation_for_po = fields.Boolean(string="PO Confirmation Needed")
    factored = fields.Boolean('Factored')
    credit_limit = fields.Json(string="Credit Limit Json", company_dependent=True) #added by myself # company_dependent should true if we use this field to be depend on each company
    credit_limit_float = fields.Float(string='Credit Limit', compute="_compute_credit_limit") #modified by myself

    customer_since = fields.Date(string='Customer Since', default=fields.date.today())
    customer_number = fields.Integer('Customer No.')
    inco_term_id = fields.Many2one('account.incoterms', 'Inco Terms')
    company_group_id = fields.Many2one('company.group','Company Group')
    division = fields.Char('Division')
    financing_method = fields.Selection([('collection','Collection'), ('credit review', 'Credit Review'), ('factoring', 'Factoring')])
    customer_status = fields.Selection([('denied', 'Denied'), ('granted','Granted'), ('validated', 'Validated')], string='Status')
    vendor_category_id = fields.Many2one(
        'vendor.category', string='Vendor Category', help='Category of the Vendor'
    )

    @api.depends('complete_name', 'email', 'vat', 'state_id', 'country_id', 'commercial_company_name')
    @api.depends_context('show_address', 'partner_show_db_id', 'address_inline', 'show_email', 'show_vat', 'lang',
                         'show_division')


    #added by myself
    @api.depends("credit_limit")
    def _compute_credit_limit(self):
        for record in self:
            if isinstance(record.credit_limit, dict):  # Ensure it's a JSON object
                record.credit_limit_float = float(record.credit_limit.get("amount", 0.0))
            else:
                record.credit_limit_float = 0.0


    def _compute_display_name(self):
        for partner in self:
            name = partner.with_context({'lang': self.env.lang})._get_complete_name()
            # for displaying the division in the many2one of customer based on the "show_division" context
            if partner._context.get('show_division') and partner.division:
                name = f"{name} ‒ {partner.division}"
            if partner._context.get('show_address'):
                name = name + "\n" + partner._display_address(without_company=True)
                print(name)
            name = re.sub(r'\s+\n', '\n', name)
            if partner._context.get('partner_show_db_id'):
                name = f"{name} ({partner.id})"
            if partner._context.get('address_inline'):
                splitted_names = name.split("\n")
                name = ", ".join([n for n in splitted_names if n.strip()])
            if partner._context.get('show_email') and partner.email:
                name = f"{name} <{partner.email}>"
            if partner._context.get('show_vat') and partner.vat:
                name = f"{name} ‒ {partner.vat}"

            partner.display_name = name.strip()

class AccountMove(models.Model):
    _inherit = 'account.move'

    # partner_credit_limit = fields.Float(string='Partner Credit Limit', compute='_compute_partner_credit_limit', store=True)
    partner_limit = fields.Float(string='Credit Limit', related="partner_id.credit_limit_float",store=True)

    # @api.depends('partner_id')
    # def _compute_partner_credit_limit(self):
    #     for record in self:
    #         record.partner_limit = record.partner_id.credit_limit if record.partner_id else 0.0

    # def create(self,vals_list):
    #     print('NNN')
    #     res = super(ResPartnerInherit,self).create(vals_list)
    #     return res


    # @api.onchange('factored')
    # def _compute_credit_limit(self):

    # @api.model_create_multi
    # def create(self, vals_list):
    #     print('yes')
    #     print(vals_list)
    #     if not vals_list.get('customer_since'):
    #         vals_list['customer_since'] = fields.Date.today()
    #     return super(ResPartnerInherit, self).create(vals_list)


class VendorCategory(models.Model):
    _name = 'vendor.category'
    _description = 'Vendor Category'

    name = fields.Char(string='Category Name', required=True)

