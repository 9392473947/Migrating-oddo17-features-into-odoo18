from odoo import fields, models, api, _

class HelpDesk(models.Model):
    _inherit = "helpdesk.ticket"

    project = fields.Many2one('project.project', 'Project')
    task = fields.Many2one('project.task', 'Task', domain="[('project_id', '=', project)]")



class ProjectUpdateNew(models.Model):
    _inherit = "project.project"

    ticket_count = fields.Integer(string='Ticket Count', compute='_compute_ticket_count')

    def _compute_ticket_count(self):
        for project in self:
            project.ticket_count = self.env['helpdesk.ticket'].search_count([('project', '=', project.id)])

    def action_view_tickets(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Tickets',
            'res_model': 'helpdesk.ticket',
            'view_mode': 'tree,form',
            'domain': [('project', '=', self.id)],
        }

    def _get_stat_buttons(self):
        buttons = super()._get_stat_buttons()
        buttons.append({
            'icon': 'list-ul',
            'text': _('Tickets'),
            'number': self.ticket_count,
            'action_type': 'object',
            'action': 'action_view_tickets',
            'show': True,
            'sequence': 70,
        })
        return buttons


class HelpdeskTicketConvertWizard(models.TransientModel):
    _inherit = 'helpdesk.ticket.convert.wizard'

    # def action_convert(self):
    #     res = super(HelpdeskTicketConvertWizard, self).action_convert()
    #     tickets_to_convert = self._get_tickets_to_convert()
    #     for ticket in tickets_to_convert:
    #         ticket.project = self.project_id
    #     return res

    # @api.model
    # def default_get(self, field_list):
    #     result = super().default_get(field_list)
    #     if 'project_id' in field_list and not result.get('project_id'):
    #         active_ticket = self.env['helpdesk.ticket'].browse(self.env.context.get('active_id'))
    #         res = self.env.context
    #         print(res,'res')
    #         print(active_ticket,'active_ticket')
    #         if active_ticket:
    #             result['project_id'] = active_ticket.project.id
    #
    #     return result

    # def _default_project_id(self, field_list):
    #     result = super().default_get(field_list)
    #     active_ticket = self.env['helpdesk.ticket'].browse(self.env.context.get('active_id'))
    #     print(active_ticket,'active_ticket')
    #     if active_ticket:
    #         result['project_id'] = active_ticket.project.id
    #
    #     return result

    def _default_project_id(self):
        active_ticket = self.env['helpdesk.ticket'].browse(self.env.context.get('active_id'))
        print(active_ticket,'active_ticket')
        if active_ticket:
            return active_ticket.project.id
        return False


# class UserLevel(models.Model):
#     _inherit = 'res.users'
#
#     lead_visibility = fields.Selection([('all','All')])
    #
    # @api.model
    # def get_lead_visibility_domain(self):
    #     if self.lead_visibility != 'all':
    #         return [('user_id', '=', self.env.user.id)]
    #     else:
    #         return []

class ProjectTask(models.Model):
    _inherit = 'project.task'

    task_ticket_count = fields.Integer(string='Ticket Count', compute='_compute_task_ticket_count')

    def _compute_task_ticket_count(self):
        for task in self:
            task.task_ticket_count = self.env['helpdesk.ticket'].search_count([('task', '=', task.id)])

    def action_view_task_tickets(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Tickets',
            'res_model': 'helpdesk.ticket',
            'view_mode': 'tree,form',
            'domain': [('task', '=', self.id)],
        }