# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from . import res_config_settings
from . import mail
from . import mail_thread
