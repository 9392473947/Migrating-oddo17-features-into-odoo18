{
    'name': 'Contact Type',
    'category': 'Contact category',
    'description': """ """,
    'depends': ['base', ],
    'data': [
        "views/res_partner.xml"
    ],

    'license': 'LGPL-3',
    "application": True,
}
