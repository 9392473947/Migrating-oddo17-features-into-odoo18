from odoo import api,models,fields

class CompanyGroup(models.Model):
    _name = "company.group"

    name = fields.Char('Company Group')