About
============
This module enhances the email sending options by adding CC & BCC by default in odoo. You can select the person in CC & BCC whom you want to send the emails as by default. You can also change CC & BCC when you compose your email.

User Guide
============
Blog: https://www.softhealer.com/blog/odoo-2/post/email-enhancement-489
Product: /shop/product/email-enhancement-495

Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list.
5) search module name and hit install button.

Any Problem with module?
=====================================
Please create your ticket here https://softhealer.com/support

Softhealer Technologies Doubt/Inquiry/Sales/Customization Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: support@softhealer.com
Website: https://softhealer.com
