17.0.1 (Feb 15,2024)
-------------------------

- initial release

17.0.2(24 April 2024)
-------------------------
[FIX]- fix singleton error when there is multiple followers

17.0.3(26 april 2024)
-------------------------
[FIX]- add manually cc in every model.

17.0.4 (30 April 2024)
----------------------------
[FIX]- show cc and bcc value at replyed mail