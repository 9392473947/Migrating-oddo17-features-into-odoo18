{
    'name': 'Stotz CRM',
    'category': 'Stotz CRM',
    'description': """ """,
    'depends': ['base', 'crm'],
    'data': [
        'security/crm_record_rule.xml',
        'views/crm_view.xml'
    ],

    'license': 'LGPL-3',
    "application": True,
}
