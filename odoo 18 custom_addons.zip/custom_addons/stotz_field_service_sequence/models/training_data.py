from odoo import models, fields


class TrainingData(models.Model):
    _name = "training.data"

    name = fields.Char('Name', required=True)
    surname = fields.Char('Surname')
    date = fields.Date('Date', required=True)
    signature = fields.Binary('Signature', required=True)
    field_service_id = fields.Many2one('project.task', 'Field service')
    worksheet_template = fields.Many2one('worksheet.template', 'Worksheet Template')
