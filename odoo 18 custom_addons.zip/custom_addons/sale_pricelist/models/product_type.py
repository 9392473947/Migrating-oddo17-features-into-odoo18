from odoo import api,models,fields

class ProductType(models.Model):
    _name = 'product.type'

    name = fields.Char(string="Name")
    product_id = fields.Many2one('product.template',string="Product")

    signal_output = fields.Selection([('analog','Analog'),('digital','Digital')],string="Signal Output")
    cable_length = fields.Char(string="Cable Length")
    # price = fields.Integer(string="Price")
