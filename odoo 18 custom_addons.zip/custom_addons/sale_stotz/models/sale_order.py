from odoo import models, fields, api, _
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError


class SaleOrderInherit(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        res = super(SaleOrderInherit, self).action_confirm()
        for rec in self:
            for line in rec.order_line:
                "check for service product and project created"
                if line.product_template_id.detailed_type == "service" and line.project_id:
                    "deadline date"
                    task_start_date = rec.commitment_date
                    plan_hours_update = dict()
                    total_for_project = 0.00
                    project_start_date = rec.commitment_date
                    product_task_object = []
                    for task in line.project_id.task_ids:
                        if line.product_template_id.name == task.name:
                            product_task_object.append(task)
                        "loop for the tasks"
                        if line.product_template_id.name != task.name and task.duration_days > 0:
                            "adds the allocated hours off all the tasks to project"
                            total_for_project += task.allocated_hours
                            "to get dates in reverse order and check for not sunday not sat and public holidays"
                            task_dates = []
                            if task_start_date:
                                for date in range(1, task.duration_days + 1):
                                    updated_date = (task_start_date + timedelta(days=-date)).date()
                                    if updated_date.weekday() == 6:
                                        updated_date = (updated_date + timedelta(days=-2))
                                    elif updated_date.weekday() == 5:
                                        updated_date = (updated_date + timedelta(days=-1))
                                    holiday_check = rec.check_for_public_holiday(updated_date, '-')
                                    "check for nay public holidays"
                                    if holiday_check:
                                        updated_date = holiday_check
                                    # print(date, 'date')
                                    if updated_date not in task_dates:
                                        task_dates.append(updated_date)
                            else:
                                raise ValidationError('Please enter the Delivery date')
                            get_days = task.duration_days
                            "task plan date"
                            task.planned_date_begin = task_dates[-1]
                            task.date_deadline = task_start_date
                            # task.date_deadline = task_dates[-1] + timedelta(days=get_days)
                            "updated the start for next task deadline date"
                            start_date_date_string = task_dates[-1] + timedelta(days=-1)
                            if start_date_date_string.weekday() == 6:
                                'check sunday'
                                start_date_date_string += timedelta(days=-2)
                            elif start_date_date_string.weekday() == 5:
                                'sat check'
                                start_date_date_string += timedelta(days=-1)
                            'check for public holidays'
                            holiday_check_for_deadline_date = rec.check_for_public_holiday(start_date_date_string, '-')
                            if holiday_check_for_deadline_date:
                                start_date_date_string = holiday_check_for_deadline_date

                            task_start_date = datetime.strptime(str(start_date_date_string), "%Y-%m-%d")
                            # check for availability and getting resource
                            "checks for the employee availability"
                            slot_data = rec.get_available_employee(task.planning_role, task, task.planned_date_begin,
                                                                   task.date_deadline)
                            # print(slot_data, 'slot_data')
                            if slot_data:
                                "once get the employee availability create plan"
                                # print(task.allocated_hours, 'task.allocated_hours')
                                # creation of the slot
                                planning_slot = self.env['planning.slot'].create({
                                    'role_id': task.planning_role.id,
                                    'no_compute_allocated_hours': True,
                                    'resource_id': slot_data.id,
                                    'project_id': line.project_id.id,
                                    'allocated_hours': task.allocated_hours,
                                    'sale_line_id': line.id,
                                    'auto_task': task.id,
                                    'start_datetime': task.planned_date_begin,
                                    'end_datetime': task.date_deadline,
                                })
                                plan_hours_update.update({
                                    planning_slot: task.allocated_hours
                                })
                                project_start_date = task.planned_date_begin
                    line.project_id.allocated_hours = total_for_project
                    line.project_id.write({
                        'date': rec.commitment_date,
                        'date_start': project_start_date,
                    })
                    for remove_product_task in product_task_object:
                        remove_product_task.unlink()

        return res

    def get_available_employee(self, role, task, task_start, task_deadline):
        no_slot = False
        "based on the resource checks for availability"
        for rec in role.resource_ids:
            # resource is employee
            if rec.employee_id:
                task_dates_list = []
                task_dates_list.append(task_start.date())
                for date in range(1, task.duration_days + 1):
                    updated_date = (task_start + timedelta(days=date)).date()
                    if updated_date.weekday() == 5:
                        updated_date += timedelta(days=2)
                    elif updated_date.weekday() == 6:
                        updated_date += timedelta(days=1)
                    public_holiday_check = self.check_for_public_holiday(updated_date, '+')
                    if public_holiday_check:
                        updated_date = public_holiday_check
                    if updated_date not in task_dates_list:
                        task_dates_list.append(updated_date)
                    # task_dates_list.append((task_start + timedelta(days=date)).date())
                working_hours = rec.employee_id.resource_calendar_id.hours_per_day
                planning = self.env['planning.slot'].search([('resource_id', '=', rec.id)])
                allocated_plans = dict()
                for plan in planning:
                    if task_start.date() <= plan.start_datetime.date() <= task_deadline.date():
                        if plan not in allocated_plans:
                            allocated_plans.update({
                                plan: plan.allocated_hours
                            })
                    if task_start.date() <= plan.end_datetime.date() <= task_deadline.date():
                        if plan not in allocated_plans:
                            allocated_plans.update({
                                plan: plan.allocated_hours
                            })
                allocated_plans_hours = sum([v for k, v in allocated_plans.items()])
                check_time_off = self.check_employee_time_off(task_dates_list, task_start, task.duration_days,
                                                              rec.employee_id) * working_hours
                total_hours_gone = allocated_plans_hours + check_time_off
                available_hours = (len(task_dates_list) * working_hours) - total_hours_gone
                if available_hours >= task.allocated_hours:
                    return rec

                no_slot = True
        if no_slot:
            raise ValidationError(f'There are no slot available in  {task.planning_role.name}.')

    def check_employee_time_off(self, task_dates_list, task_start, task_duration, employee):
        time_off = self.env['hr.leave'].search(
            [('all_employee_ids', 'in', [employee.id]), ('state', '=', 'validate')])
        time_offs = []
        for rec in time_off:
            task_dates = task_dates_list
            # task_dates.append(task_start.date())
            # for date in range(1, task_duration + 1):
            #     task_dates.append((task_start + timedelta(days=date)).date())
            # print(task_dates, 'task_dates')
            for date in task_dates:
                # chained comparison
                if rec.request_date_from <= date <= rec.request_date_to:
                    if rec.holiday_status_id.name == "Sick Time Off":
                        time_offs.append(rec.number_of_days_display)
                    elif rec.holiday_status_id.name == 'Unpaid':
                        if rec.request_unit_half:
                            time_offs.append(rec.number_of_days_display)
        # total time off in days
        return sum(time_offs)

    def check_for_public_holiday(self, date, symbol):
        res = self.env['resource.calendar.leaves'].search([])
        check_date = date
        for rec in res:
            if rec.date_from.date() <= check_date <= rec.date_to.date():
                if symbol == '-':
                    check_date += timedelta(days=-1)
                    if check_date.weekday() == 6:
                        check_date += timedelta(days=-2)
                    elif check_date.weekday() == 5:
                        check_date += timedelta(days=-1)
                    self.check_for_public_holiday(check_date, symbol)
                elif symbol == "+":
                    check_date += timedelta(days=1)
                    if check_date.weekday() == 5:
                        check_date += timedelta(days=2)
                    elif check_date.weekday() == 6:
                        check_date += timedelta(days=1)
                    self.check_for_public_holiday(check_date, symbol)

        return check_date

    def empty_slot_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Check Availability'),
            'res_model': 'empty.slot',
            'views': [[False, 'form']],
            'domain': [],
            'target': 'new',
        }
