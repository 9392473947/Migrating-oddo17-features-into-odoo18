from odoo import api,models,fields

class ProductSymmetry(models.Model):
    _name = 'product.symmetry'

    name = fields.Char(string="Name")
    code = fields.Char(string="Code")
    surcharge = fields.Integer(string="Surcharge per Mandrel")