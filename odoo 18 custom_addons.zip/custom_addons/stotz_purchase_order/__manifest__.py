{
    'name' : 'Purchase order stotz',
    'version' : '2.0',
    'author': 'Nivetha',
    'summary': 'purchase order scheduled activity',
    'sequence': 10,
    'depends': ['purchase','base','mrp','mrp_subcontracting_purchase','stock'],
    'data': [
        'data/cron.xml',
        'security/security.xml',
        'views/subcontract.xml',



    ],

    'installable': True,

    'module_type': 'official',
    'license': 'LGPL-3'
}