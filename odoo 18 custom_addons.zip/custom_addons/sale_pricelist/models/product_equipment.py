from odoo import api,models,fields

class ProductEquipment(models.Model):
    _name = 'product.equipment'


    name = fields.Char(string="Name")
    code = fields.Char(string="Code")
    price = fields.Float(string="Price")