{
    'name' : 'Stotz Customer Data',
    'depends': ['base','account'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_partner_form_view.xml',
    ],
    'installable': True,
    'module_type': 'official',
}