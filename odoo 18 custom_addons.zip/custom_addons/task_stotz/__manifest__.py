{
    'name': 'Stotz Task Module',
    'category': 'Project Task',
    'description': """ """,
    'depends': ['base', 'project', 'project_enterprise', 'web_gantt'], #added web_gantt
    'data': [
        "views/project_task.xml",
    ],
    "application": True,
    'assets': {
        'web.assets_backend': [
            'web_gantt/static/src/gantt_renderer.js',
            'web_gantt/static/src/gantt_connector.js',
            'web_gantt/static/src/gantt_helpers.js',
            'web_gantt/static/src/gantt_popover.js',
            'web_gantt/static/src/gantt_renderer_controls.js',
            'web_gantt/static/src/gantt_resize_badge.js',
            'web_gantt/static/src/gantt_row_progress_bar.js',
            'web_gantt/static/src/gantt_popover_in_dialog.js',
            'web_gantt/static/src/gantt_compiler.js',
            # 'task_stotz/static/src/js/**/*' -- comment it out since this w global pattern wont work in odoo18
            'task_stotz/static/src/js/gantt_view.js'
        ],
    },
}
