{
    "name": "Project Enhancement",
    "author": "PMCPL",
    "version": "0.0.1",
    "license": "LGPL-3",
    "depends": ['project'],
    "data": [
        "security/ir.model.access.csv",
        "wizard/project_template_select.xml",
        "views/project.xml",
    ],
    "installable": True,
    "auto_install": False,
    "application": True,
}
