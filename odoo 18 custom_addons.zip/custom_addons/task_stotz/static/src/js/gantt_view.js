/* @odoo-module */

import { GanttRenderer } from "@web_gantt/gantt_renderer";
import { patch } from "@web/core/utils/patch";



patch(GanttRenderer.prototype, {
    getDisplayName(pill) {
        const { scale } = this.model.metaData;
        const { record } = pill
        if (scale.id === "month" || scale.id === "week"){
            if ('partner_id_city' in record){
                if (record.partner_id_city){
                    const res = super.getDisplayName(pill) + ' - ' + record.partner_id_city
                    return res
                }
            }
        }
        return super.getDisplayName(pill)
    }

})