from odoo import models, fields, api
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError


class ProjectTask(models.Model):
    _inherit = 'project.task'

    previous_planned_date = fields.Datetime('Previous Planned Date')
    previous_deadline_date = fields.Datetime('Previous Deadline Date')
    partner_id_city = fields.Char(related='partner_id.city', store=True)
    planning_role = fields.Many2one('planning.role', 'Role')
    duration_days = fields.Integer('Days', compute="_compute_duration_days", store=True)

    @api.depends('planned_date_begin', 'date_deadline')
    def _compute_duration_days(self):
        # to the in between days of start and end
        for rec in self:
            if rec.planned_date_begin and rec.date_deadline:
                days = rec.date_deadline.date() - rec.planned_date_begin.date()
                rec.duration_days = days.days

    # def create(self, vals_list):
    #     # updating the previously exist date
    #     res = super(ProjectTask, self).create(vals_list)
    #     res['previous_planned_date'] = res['planned_date_start']
    #     res['previous_deadline_date'] = res['date_deadline']
    #     return res

    def write(self, vals):
        # Store previous deadline dates for all tasks before any changes are made
        previous_deadline_dates = {task.id: [task.date_deadline, task.planned_date_begin] for task in self}
        # Perform the write operation
        res = super(ProjectTask, self).write(vals)
        for task in self:
            get_date_end_previous = previous_deadline_dates.get(task.id)[0]
            get_date_start_previous = previous_deadline_dates.get(task.id)[1]
            if get_date_start_previous and get_date_start_previous == task.planned_date_begin:
                dependent_tasks = self.env['project.task'].search([('depend_on_ids', 'in', [task.id])])
                for dep_task in dependent_tasks:
                    if task.date_deadline and dep_task.planned_date_begin:
                        if task.date_deadline.date() > dep_task.planned_date_begin.date():
                            if get_date_start_previous:
                                get_days = task.date_deadline - dep_task.planned_date_begin
                                get_hours = int(get_days.seconds / 3600.0)
                                get_mins = int(get_days.seconds / 60)
                                original_datetime_plan = fields.Datetime.from_string(dep_task.planned_date_begin)
                                original_datetime_deadline = fields.Datetime.from_string(dep_task.date_deadline)
                                if get_days.days > 0:
                                    dep_task.write({
                                        'date_deadline': original_datetime_deadline + timedelta(days=get_days.days),
                                        'planned_date_begin': original_datetime_plan + timedelta(days=get_days.days),
                                    })
                                elif get_mins > 0 and not get_days.days < 0:
                                    dep_task.write({
                                        'date_deadline': original_datetime_deadline + timedelta(minutes=get_mins),
                                        'planned_date_begin': original_datetime_plan + timedelta(minutes=get_mins),
                                    })
                        elif task.date_deadline.date() == dep_task.planned_date_begin.date():
                            if task.date_deadline.time() >= dep_task.planned_date_begin.time():
                                if get_date_start_previous:
                                    get_days = task.date_deadline - dep_task.planned_date_begin
                                    original_datetime_plan = fields.Datetime.from_string(dep_task.planned_date_begin)
                                    original_datetime_deadline = fields.Datetime.from_string(dep_task.date_deadline)
                                    get_hours = int(get_days.seconds / 3600.0)
                                    get_mins = int(get_days.seconds / 60)
                                    if get_days.days > 0:
                                        dep_task.write({
                                            'date_deadline': original_datetime_deadline + timedelta(days=get_days.days),
                                            'planned_date_begin': original_datetime_plan + timedelta(
                                                days=get_days.days),
                                        })
                                    elif get_mins > 0 and not get_days.days < 0:
                                        dep_task.write({
                                            'date_deadline': original_datetime_deadline + timedelta(minutes=get_mins),
                                            'planned_date_begin': original_datetime_plan + timedelta(minutes=get_mins),
                                        })
            else:
                dependent_tasks = self.env['project.task'].search([('depend_on_ids', 'in', [task.id])])
                for dep_task in dependent_tasks:
                    if task.date_deadline and dep_task.planned_date_begin:
                        if task.date_deadline.date() > dep_task.planned_date_begin.date():
                            if get_date_end_previous:
                                get_days = task.date_deadline - get_date_end_previous
                                get_hours = int(get_days.seconds / 3600.0)
                                get_mins = int(get_days.seconds / 60)
                                original_datetime_plan = fields.Datetime.from_string(dep_task.planned_date_begin)
                                original_datetime_deadline = fields.Datetime.from_string(dep_task.date_deadline)
                                if get_days.days > 0:
                                    dep_task.write({
                                        'date_deadline': original_datetime_deadline + timedelta(days=get_days.days),
                                        'planned_date_begin': original_datetime_plan + timedelta(days=get_days.days),
                                    })
                                elif get_mins > 0 and not get_days.days < 0:
                                    dep_task.write({
                                        'date_deadline': original_datetime_deadline + timedelta(minutes=get_mins),
                                        'planned_date_begin': original_datetime_plan + timedelta(minutes=get_mins),
                                    })
                        elif task.date_deadline.date() == dep_task.planned_date_begin.date():
                            if task.date_deadline.time() >= dep_task.planned_date_begin.time():
                                if get_date_end_previous:
                                    get_days = task.date_deadline - get_date_end_previous
                                    original_datetime_plan = fields.Datetime.from_string(dep_task.planned_date_begin)
                                    original_datetime_deadline = fields.Datetime.from_string(dep_task.date_deadline)
                                    get_hours = int(get_days.seconds / 3600.0)
                                    get_mins = int(get_days.seconds / 60)
                                    if get_days.days > 0:
                                        dep_task.write({
                                            'date_deadline': original_datetime_deadline + timedelta(days=get_days.days),
                                            'planned_date_begin': original_datetime_plan + timedelta(
                                                days=get_days.days),
                                        })
                                    elif get_mins > 0 and not get_days.days < 0:
                                        dep_task.write({
                                            'date_deadline': original_datetime_deadline + timedelta(minutes=get_mins),
                                            'planned_date_begin': original_datetime_plan + timedelta(minutes=get_mins),
                                        })
        return res


class ProjectMilestone(models.Model):
    _inherit = 'project.milestone'

    @api.constrains('is_reached')
    def check_task_state_done(self):
        for rec in self:
            if rec.task_ids.filtered(lambda t: t.state != '1_done'):
                if rec.is_reached == True:
                    raise ValidationError("You can't complete the milestone, please review open task.")
