from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import subprocess
import logging
_logger = logging.getLogger(__name__)


class ProductPricelistItemInherit(models.Model):
    _inherit = 'product.pricelist.item'

    length_range = fields.Char(string="Length")
    diameter_range = fields.Char(string="Diameter")
    length_code = fields.Char(string="Length Code")
    diameter_code = fields.Char(string="Diameter Code")
    signal_output = fields.Selection([('analog','Analog'),('digital','Digital')],string="Signal Output")
    cable_length = fields.Char(string="Cable Length")



    @api.onchange('length_range', 'diameter_range')
    def _check_range_format(self):
        for record in self:
            if record.length_range:
                if not self._validate_range_format(record.length_range):
                    raise ValidationError("Invalid length range format. Please use number-number format (e.g., 10-20)")
            if record.diameter_range :
                if not self._validate_range_format(record.diameter_range):
                    raise ValidationError("Invalid diameter range format. Please use number-number format (e.g., 5-15)")

    @staticmethod
    def _validate_range_format(value):
        """ Validate format of range fields """
        if not isinstance(value, str):
            return False
        parts = value.split('-')
        if len(parts) != 2:
            return False
        try:
            start = float(parts[0].strip())
            end = float(parts[1].strip())
            if start >= end:
                return False
        except ValueError:
            return False
        return True


class SaleOrderLineInherit(models.Model):
    _inherit = 'sale.order.line'


    length = fields.Float(string="Length")
    diameter = fields.Float(string="Diameter")
    product_code = fields.Char(
        related='product_template_id.code',
        string="Product Code",
        readonly=True,

    )


    # product_type_new = fields.Selection(
    #     related='product_template_id.type_new',
    #     string="Product Types",
    #     readonly=True
    # )

    product_types_new = fields.Many2one('product.type',string="Product Types")

    product_material = fields.Many2one('product.material',string="Product Material")
    product_symmetry = fields.Many2one('product.symmetry',string="Product Symmetry")
    product_equipment = fields.Many2one('product.equipment',string="Product Equipment")

    signal_output = fields.Selection([('analog', 'Analog'), ('digital', 'Digital')], string="Signal Output")
    cable_length = fields.Char(string="Cable Length")
    product_type_domain = fields.Many2many('product.type', string="Product Types Domain",
                                           compute='_compute_product_type_domain')



    @api.depends('product_template_id')
    def _compute_product_type_domain(self):
        for line in self:
            if line.product_template_id:
                line.product_type_domain = self.env['product.type'].search(
                    [('product_id', '=', line.product_template_id.id)])
            else:
                line.product_type_domain = self.env['product.type'].search([])


    @api.onchange('product_template_id')
    def _onchange_product_template_id(self):
        self.product_types_new = False




    @api.onchange('product_template_id')
    def onchange_product_template_id(self):
        if self.product_template_id:
            self.product_id = self.product_template_id.product_variant_id.id



    @api.onchange('product_template_id','length', 'diameter', 'product_material', 'product_symmetry', 'product_equipment','product_types_new','cable_length','signal_output')
    def _onchange_length_diameter(self):
        if self.length or self.diameter or self.product_material or self.product_symmetry or self.product_equipment or (self.product_types_new and self.cable_length and self.signal_output):
            self._compute_price_unit()


    @api.onchange('product_template_id', 'product_uom', 'product_uom_qty', 'length', 'diameter', 'product_material',
                 'product_symmetry', 'product_equipment','product_types_new','cable_length','signal_output')
    def _compute_price_unit(self):
        for line in self:
            if line.qty_invoiced > 0:
                continue

            if line.product_template_id and self.order_id.pricelist_id or line.product_equipment:
                   pricelist_id = self.order_id.pricelist_id

                   pricelist_records = self.env['product.pricelist.item'].search([
                        ('product_tmpl_id', '=', self.product_template_id.id),
                        ('pricelist_id', '=', pricelist_id.id),

                    ])

                   if pricelist_records:
                       for item in pricelist_records:
                           fetched_price = item.fixed_price
                           if line.product_equipment:
                               equipment = line.product_equipment
                               fetched_price+= equipment.price
                           line.price_unit = fetched_price
                           break

            if line.product_types_new and line.signal_output and line.cable_length:
                print("type")
                pricelist_type = line._find_matching_pricelist_type()
                if pricelist_type:
                    for item in pricelist_type:
                        print(item.cable_length,item.fixed_price)
                        fetched_price = item.fixed_price
                        line.price_unit = fetched_price
                        print("Order line price", self.price_unit)
                        break
                else:
                    raise ValidationError(
                        _("No matching pricelist found for the product, cable length, and signal output."))

            if line.length or line.diameter:
                pricelist_item = line._find_matching_pricelist_item()
                product_material_line = line.product_material
                product_symmetry_line = line.product_symmetry
                product_equipment_line = line.product_equipment

                if pricelist_item:
                    base_price = pricelist_item.fixed_price
                    if product_material_line:
                        base_price += product_material_line.surcharge
                    if product_symmetry_line:
                        base_price += product_symmetry_line.surcharge
                    if product_equipment_line:
                        base_price += product_equipment_line.price

                    line.price_unit = base_price
                    continue

                # Check if only length or diameter range is specified in pricelist
                pricelist_items = line._get_pricelist_items()
                if line.length and not any(item.length_range for item in pricelist_items):
                    raise ValidationError(_("No length found for this product in pricelist."))
                if line.diameter and not any(item.diameter_range for item in pricelist_items):
                    raise ValidationError(_("No diameter found for this product in pricelist."))
                # raise ValidationError(_("No pricelist item found for the entered length and diameter."))



            if not line.price_unit:
                super(SaleOrderLineInherit, line)._compute_price_unit()


    def _find_matching_pricelist_type(self):
        self.ensure_one()

        pricelist_id = self.order_id.pricelist_id

        return self.env['product.pricelist.item'].search([
            ('product_tmpl_id', '=', self.product_template_id.id),
            ('pricelist_id', '=', pricelist_id.id),
            ('min_quantity', '<=', self.product_uom_qty or 1.0),

            ('signal_output', '=', self.signal_output),
            ('cable_length','=',self.cable_length),

        ])

    def _find_matching_pricelist_item(self):

        """ Find the matching pricelist item based on length and diameter """
        self.ensure_one()

        pricelist_items = self._get_pricelist_items()

        print("pricleist items", pricelist_items)

        for item in pricelist_items:
            if self.length and self.diameter:
                if (self._check_length_in_range(item.length_range) and
                        self._check_diameter_in_range(item.diameter_range)):
                    return item
            elif self.length:
                if self._check_length_in_range(item.length_range):
                    # Check if diameter is also provided but no range for diameter in pricelist
                    if self.diameter and not item.diameter_range:
                        raise ValidationError(_("No diameter range found for this product in pricelist."))
                    return item
            elif self.diameter:
                if self._check_diameter_in_range(item.diameter_range):
                    # Check if length is also provided but no range for length in pricelist
                    if self.length and not item.length_range:
                        raise ValidationError(_("No length range found for this product in pricelist."))
                    return item





        return None

    def _get_pricelist_items(self):


        """ Get pricelist items for the product """
        return self.env['product.pricelist.item'].search([
            ('product_tmpl_id', '=', self.product_template_id.id),
            ('min_quantity', '<=', self.product_uom_qty or 1.0),
            '|', ('length_range', '!=', False), ('diameter_range', '!=', False),

        ])

    def _check_length_in_range(self, length_range):
        """ Check if the entered length is within the pricelist item's length_range """
        if not length_range:
            return False  # Consider invalid if length_range is not specified
        min_length, max_length = map(float, length_range.split('-'))
        return min_length <= self.length <= max_length

    def _check_diameter_in_range(self, diameter_range):
        """ Check if the entered diameter is within the pricelist item's diameter_range """
        if not diameter_range:
            return False  # Consider invalid if diameter_range is not specified
        min_diameter, max_diameter = map(float, diameter_range.split('-'))
        return min_diameter <= self.diameter <= max_diameter


    @api.depends('product_code', 'product_types_new', 'product_material', 'product_symmetry','product_equipment',
                 'product_template_id.channel', 'product_template_id.jets', 'diameter', 'length')
    def _compute_name(self):
        super(SaleOrderLineInherit, self)._compute_name()
        for line in self:
            parts = []

            if line.product_code:
                parts.append(line.product_code)

            if line.product_types_new:
                parts.append(line.product_types_new.name)
                # type_display_name = dict(
                #     line.fields_get(allfields=['product_types_new'])['product_types_new']['selection']).get(
                #     line.product_types_new)
                # if type_display_name:
                #     parts.append(type_display_name)


            if line.product_template_id.channel:
                parts.append(line.product_template_id.channel.code)

            if line.diameter:
                # Find the pricelist item that matches the length and diameter
                pricelist_item = line._find_matching_pricelist_item()
                if pricelist_item:
                    parts.append(pricelist_item.diameter_code)

            if line.length:
                # Find the pricelist item that matches the length and diameter
                pricelist_item = line._find_matching_pricelist_item()
                if pricelist_item:
                    parts.append(pricelist_item.length_code)

            # Count jets and add to name
            if line.product_template_id.jets:
               parts.append(line.product_template_id.jets.code)

            if line.product_material:
                parts.append(line.product_material.code)

            if line.product_symmetry:
                parts.append(line.product_symmetry.code)

            # if line.product_equipment:
            #     parts.append(line.product_equipment.code)

            # Join all parts to form the final name
            if len(parts) > 2:
                joined_parts = '-'.join(parts[2:])  # Start from index 2 to skip product_code and product_types_new
            else:
                joined_parts = ''

            if len(parts) >= 2:
                line.name = f"{parts[0]}{parts[1]}-{joined_parts}"
            elif len(parts) == 1:
                line.name = parts[0]
            else:
                line.name = line.product_template_id.name




class ProductTemplateInherit(models.Model):
    _inherit = 'product.template'

    code = fields.Char(string="Material Code")


    type_new = fields.Selection([('k', 'K'), ('m', 'M'), ('p', 'P')], string="Material type")


    channel = fields.Many2one('product.channel',string="Channel")
    jets = fields.Many2one('product.jet',string="Jets")
    confirmation_given = fields.Boolean(string="Confirmation Given", default=False, readonly=True)
    product_drawing_number = fields.Integer('Drawing Number')

    @api.constrains('channel', 'jets')
    def _check_channel_and_jets(self):
        for record in self:
            if (record.channel and not record.jets) or (record.jets and not record.channel):
                raise ValidationError("Both Channel and Jets must be selected together.")

            if (record.channel and  record.jets):
                record.confirmation_given = True



    @api.onchange('channel', 'jets')
    def change_product_name(self):
        # Define a separator
        separator = "  "

        if self.name:
            # Extract the base name by removing any existing channel or jets names
            base_name = self.name.split(separator)[0]
        else:
            base_name = ""

        # Build the new name with the base name, channel, and jets
        additions = []
        if self.channel:
            additions.append(self.channel.name)
        if self.jets:
            additions.append(self.jets.name)

        # Join the base name with the additions using the separator
        self.name = base_name + (separator + separator.join(additions) if additions else "")

    vpn_username = fields.Char('VPN Username')
    vpn_password = fields.Char('VPN Password', password=True)

    def connect_to_vpn(self):
        vpn_path = '/mnt/extra-addons/sale_pricelist/static/src/vpn_config/odoo@intern.stotz.com.ovpn'

        # Prepare the command to start OpenVPN
        vpn_command = f'sudo openvpn --config {vpn_path}'
        _logger.info(vpn_command)

        # Create a temporary file to handle the input of username and password
        with open('/tmp/vpn_auth.txt', 'w') as auth_file:
            _logger.info('opened')
            auth_file.write(f"{self.vpn_username}\n{self.vpn_password}\n")
            _logger.info('written')
        _logger.info('withhhhhh')

        # Use subprocess to run the VPN command with the username and password
        process = subprocess.Popen(vpn_command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        _logger.info(process)
        stdout, stderr = process.communicate(input=b'\n')

        if process.returncode == 0:
            _logger.info('VPN started successfully')
            return 'VPN started successfully'

        else:
            _logger.info('VPN Stop')
            return f'Error starting VPN: {stderr.decode()}'