{
    'name': 'Stotz Sales Module',
    'category': 'Sales Project Task',
    'description': """ """,
    'depends': ['base', 'sale','sale_project', 'planning'],
    'data': [
        'security/ir.model.access.csv',
        'views/sale_order.xml',
        'views/planning_slot.xml',
        'wizards/empty_wizard.xml',

    ],
    'license': 'LGPL-3',
    "application": True,
    'assets': {
        'web.assets_backend': [
            # 'sale_stotz/static/src/js/**/*'
        ],
    },
}
