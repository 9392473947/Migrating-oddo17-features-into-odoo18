/** @odoo-module **/

//import { registerPatch } from '@mail/model/model_core';
//import { attr } from '@mail/model/model_field';

import { patch } from "@web/core/utils/patch";
import { Message } from "@mail/core/common/message_model";

patch(Message.prototype, {
         convertData(data) {
           const res = this.super(data);
           if ('cc_email' in data) {
               res.cc_mail = data.cc_email;
               }
           if ('bcc_email' in data) {
               res.bcc_email = data.bcc_email;
           }
           return res;
           },
});

//registerPatch({
//    name: 'Message',
//    modelMethods: {
//        /**
//         * @override
//         */
//        convertData(data) {
//        	 const res = this._super(data);
//             if ('cc_email' in data) {
//                 res.cc_email = data.cc_email;
//             }
//             if ('bcc_email' in data) {
//                 res.bcc_email = data.bcc_email;
//             }
//             return res;
//        },
//    },
//    fields: {
//    	cc_email: attr(),
//        bcc_email: attr(),
//
//    },
//});
///** @odoo-module **/
//
//import { patch } from '@web/core/utils/patch';
//const mail_message = mail.components.Message; //access mail message component from mail module
//
//
//patch(mail_message, 'mail.Message', { // Replace 'your_module' with your module's name
//    _fields: {
//        cc_email: attr(),
//        bcc_email: attr(),
//    },
//    convertData(data) {
//        const res = this._super(data);
//        if ('cc_email' in data) {
//            res.cc_email = data.cc_email;
//        }
//        if ('bcc_email' in data) {
//            res.bcc_email = data.bcc_email;
//        }
//        return res;
//    },
//});