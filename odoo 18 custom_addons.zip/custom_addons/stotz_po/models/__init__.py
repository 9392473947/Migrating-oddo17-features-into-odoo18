from . import res_partner_form
from . import po_vendor_specific
from . import vendor_pricelist
from . import purchase_order