import json
from odoo import models, fields
from odoo.exceptions import UserError, ValidationError
import ast


class PdfCompare(models.TransientModel):
    _name = 'pdf.compare'

    po = fields.Many2one('purchase.order', 'Purchase Order')
    upload_ocr_pdf = fields.Binary('')
    updates = fields.Html('')
    compare_ids = fields.One2many('compare.values', 'pdf_compare')
    see_report_text = fields.Boolean('See Report')
    openai_output = fields.Char('OpenAI Output')
    purchase_order = fields.Many2one('purchase.order', 'Purchase Order')
    report_view = fields.Binary('View Report')
    stock_picking_id = fields.Many2one('stock.picking', )
    product_lines_update = fields.Char('')

    def default_get(self, fields_list):
        res = super(PdfCompare, self).default_get(fields_list)
        if 'openai_output' in res:
            report_dict = json.loads(res['openai_output'])
            if 'purchase_order' in res:
                res['compare_ids'] = self.po_report_compared_values(res, report_dict)
            if 'stock_picking_id' in res:
                res['compare_ids'] = self.receipt_report_compared_values(res, report_dict)

        return res

    def po_report_compared_values(self, res, report_dict):
        compare_vals_list = []
        po = self.env['purchase.order'].browse(res['purchase_order'])
        po_lines = po.order_line
        for report_val in report_dict:
            if 'customer_details' in report_val:
                cd = report_dict.get('customer_details')
                if cd.get('customer_name', False):
                    style = ''
                    if cd.get('customer_name', ).upper() == po.company_id.name.upper():
                        style = "style='color:green'"
                    else:
                        style = "style='color:red'"
                    compare_vals_customer = self.env['compare.values'].create({
                        'odoo_values': f"<div {style}> {po.company_id.name} </div>",
                        'report_values': f"<div {style}>{cd.get('customer_name', )} "
                                         f"</div>",
                    })
                    compare_vals_list.append(compare_vals_customer.id)
                if cd.get('vendor_name', False):
                    vendor_style = ''
                    if cd.get('vendor_name', ).upper() == po.partner_id.name.upper():
                        vendor_style = "style='color:green'"
                    else:
                        vendor_style = "style='color:red'"
                    compare_vals_vendor = self.env['compare.values'].create({
                        'odoo_values': f"Vendor Name :  <div {vendor_style}>{po.partner_id.name} </div>",
                        'report_values': f"Vendor Name :  <div {vendor_style}>{cd.get('vendor_name', )} </div>",
                    })
                    compare_vals_list.append(compare_vals_vendor.id)
                if cd.get('purchase_order_number', False):
                    po_name_style = ''
                    if cd.get('purchase_order_number', ).upper() == po.name.upper():
                        po_name_style = "style='color:green'"
                    else:
                        po_name_style = "style='color:red'"
                    compare_vals_po_name = self.env['compare.values'].create({
                        'odoo_values': f"Purchase Order Number :  <div {po_name_style}>{po.name} </div>",
                        'report_values': f"Purchase Order Number :  <div {po_name_style}>{cd.get('purchase_order_number', )} </div>",
                    })
                    compare_vals_list.append(compare_vals_po_name.id)
            if 'products' in report_val:
                p = report_dict.get('products')
                # for updating the new values to record from the report
                product_lines_to_update = []
                for product in p:
                    product_lines_to_update_dict = dict()
                    if 'product_name' in product:
                        get_product = po_lines.filtered(lambda p: p.product_id.name == product.get('product_name'))
                        if len(get_product) > 1:
                            raise ValidationError(
                                f"Multiple products found with the name '{product.get('product_name')}'. Please ensure the product name is unique.")
                        product_name_style = ''
                        if get_product:
                            product_name_style = "style='color:green;'"
                            product_lines_to_update_dict.update({
                                'product_name': product.get('product_name')
                            })
                        else:
                            product_name_style = "style='color:red'"

                        compare_vals_product_name = self.env['compare.values'].create({
                            'odoo_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <div ><h4 {product_name_style}>{get_product.product_id.name}</h4> </div>",
                            'report_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <div ><h4 {product_name_style}>{product.get('product_name', )}</h4> </div>",
                        })
                        compare_vals_list.append(compare_vals_product_name.id)

                        if get_product:
                            if 'quantity' in product:
                                qty_style = ""
                                if product.get('quantity') == get_product.product_qty:
                                    qty_style = "style='color:green'"
                                else:
                                    product_lines_to_update_dict.update({
                                        'quantity': product.get('quantity')
                                    })
                                    qty_style = "style='color:red'"
                                compare_vals_qty = self.env['compare.values'].create({
                                    'odoo_values': f"Quantity : <div {qty_style}>{get_product.product_qty} </div>",
                                    'report_values': f"Quantity : <div {qty_style}>{product.get('quantity', )} </div>",
                                })
                                compare_vals_list.append(compare_vals_qty.id)
                            if 'unit_price' in product:
                                unit_price_style = ""
                                if product.get('unit_price') == get_product.price_unit:
                                    unit_price_style = "style='color:green'"
                                else:
                                    product_lines_to_update_dict.update({
                                        'unit_price': product.get('unit_price')
                                    })
                                    unit_price_style = "style='color:red'"
                                compare_vals_unit_price = self.env['compare.values'].create({
                                    'odoo_values': f"Unit Price : <div {unit_price_style}>{get_product.price_unit} </div>",
                                    'report_values': f"Unit Price : <div {unit_price_style}>{product.get('unit_price', )} </div>",
                                })
                                compare_vals_list.append(compare_vals_unit_price.id)
                            if 'total_price' in product:
                                total_price_style = ""
                                if product.get('total_price') == get_product.price_subtotal:
                                    total_price_style = "style='color:green'"
                                else:
                                    product_lines_to_update_dict.update({
                                        'total_price': product.get('total_price')
                                    })
                                    total_price_style = "style='color:red'"
                                compare_vals_total_price = self.env['compare.values'].create({
                                    'odoo_values': f"Total Price : <div {total_price_style}>{get_product.price_subtotal} </div>",
                                    'report_values': f"Total Price : <div {total_price_style}>{product.get('total_price', )} </div>",
                                })
                                compare_vals_list.append(compare_vals_total_price.id)
                    product_lines_to_update.append(product_lines_to_update_dict)
                res['product_lines_update'] = product_lines_to_update
                for product_line in po_lines:
                    product_exists = any(product['product_name'] == product_line.product_id.name for product in p)
                    if not product_exists:
                        product_not_in_report = self.env['compare.values'].create({
                            'odoo_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <h4 style='color:red;'>{product_line.product_id.name} </h4>",
                            'report_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <h4 style='color:red;'>False</h4>",
                        })
                        compare_vals_list.append(product_not_in_report.id)
        return [(6, 0, compare_vals_list)]

    def receipt_report_compared_values(self, res, report_dict):
        compare_vals_list = []
        sp = self.env['stock.picking'].browse(res['stock_picking_id'])
        sp_lines = sp.move_ids_without_package
        for report_val in report_dict:
            if 'customer_details' in report_val:
                cd = report_dict.get('customer_details')
                if cd.get('customer_name', False):
                    style = ''
                    if cd.get('customer_name', ).upper() == sp.company_id.name.upper():
                        style = "style='color:green'"
                    else:
                        style = "style='color:red'"
                    compare_vals_customer = self.env['compare.values'].create({
                        'odoo_values': f"Company Name : <div {style}> {sp.company_id.name} </div>",
                        'report_values': f"Company Name : <div {style}>{cd.get('customer_name', )} </div>",
                    })
                    compare_vals_list.append(compare_vals_customer.id)
                if cd.get('vendor_name', False):
                    vendor_style = ''
                    if cd.get('vendor_name', ).upper() == sp.partner_id.name.upper():
                        vendor_style = "style='color:green'"
                    else:
                        vendor_style = "style='color:red'"
                    compare_vals_vendor = self.env['compare.values'].create({
                        'odoo_values': f"Vendor Name :  <div {vendor_style}>{sp.partner_id.name} </div>",
                        'report_values': f"Vendor Name :  <div {vendor_style}>{cd.get('vendor_name', )} </div>",
                    })
                    compare_vals_list.append(compare_vals_vendor.id)
                if cd.get('purchase_order_number', False):
                    po_name_style = ''
                    if cd.get('purchase_order_number', ).upper() == sp.name.upper():
                        po_name_style = "style='color:green'"
                    else:
                        po_name_style = "style='color:red'"
                    compare_vals_po_name = self.env['compare.values'].create({
                        'odoo_values': f"Receipt Number :  <div {po_name_style}>{sp.name} </div>",
                        'report_values': f"Receipt Number :  <div {po_name_style}>{cd.get('purchase_order_number', )} </div>",
                    })
                    compare_vals_list.append(compare_vals_po_name.id)

            if 'products' in report_val:
                p = report_dict.get('products')
                # to store the values in list using that we can able update the quantity
                product_lines_to_update = []
                for product in p:

                    product_lines_to_update_dict = dict()
                    if 'product_name' in product:
                        get_product = sp_lines.filtered(lambda p: p.product_id.name == product.get('product_name'))
                        if len(get_product) > 1:
                            raise ValidationError(
                                f"Multiple products found with the name '{product.get('product_name')}'. Please ensure the product name is unique.")
                        product_name_style = ''
                        if get_product:
                            product_lines_to_update_dict.update({
                                'product_name': product.get('product_name')
                            })
                            product_name_style = "style='color:green;'"
                        else:
                            product_name_style = "style='color:red'"

                        compare_vals_product_name = self.env['compare.values'].create({
                            'odoo_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <div ><h4 {product_name_style}>{get_product.product_id.name}</h4> </div>",
                            'report_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <div ><h4 {product_name_style}>{product.get('product_name', )}</h4> </div>",
                        })
                        compare_vals_list.append(compare_vals_product_name.id)

                        if get_product:
                            if 'quantity' in product:
                                qty_style = ""
                                if product.get('quantity') == get_product.product_uom_qty:
                                    qty_style = "style='color:green'"
                                else:
                                    qty_style = "style='color:red'"
                                compare_vals_qty = self.env['compare.values'].create({
                                    'odoo_values': f"Quantity : <div {qty_style}>{get_product.product_uom_qty} </div>",
                                    'report_values': f"Quantity : <div {qty_style}>{product.get('quantity', )} </div>",
                                })
                                product_lines_to_update_dict.update({
                                    'quantity': product.get('quantity')
                                })
                                compare_vals_list.append(compare_vals_qty.id)
                    product_lines_to_update.append(product_lines_to_update_dict)
                res['product_lines_update'] = product_lines_to_update
                for product_line in sp_lines:
                    product_exists = any(product['product_name'] == product_line.product_id.name for product in p)
                    if not product_exists:
                        product_not_in_report = self.env['compare.values'].create({
                            'odoo_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <h4 style='color:red;'>{product_line.product_id.name} </h4>",
                            'report_values': f"<table width='100%'><tr><td style='width:100%;border-top:1px solid black; '></td><tr></table>Product Name : <h4 style='color:red;'>False</h4>",
                        })
                        compare_vals_list.append(product_not_in_report.id)

                # if 'unit_price' in product:
                #     unit_price_style = ""
                #     if product.get('unit_price') == get_product.price_unit:
                #         unit_price_style = "style='color:green'"
                #     else:
                #         unit_price_style = "style='color:red'"
                #     compare_vals_unit_price = self.env['compare.values'].create({
                #         'odoo_values': f"Unit Price : <div {unit_price_style}>{get_product.price_unit} </div>",
                #         'report_values': f"Unit Price : <div {unit_price_style}>{product.get('unit_price', )} </div>",
                #     })
                #     compare_vals_list.append(compare_vals_unit_price.id)
                # if 'total_price' in product:
                #     total_price_style = ""
                #     if product.get('total_price') == get_product.price_subtotal:
                #         total_price_style = "style='color:green'"
                #     else:
                #         total_price_style = "style='color:red'"
                #     compare_vals_total_price = self.env['compare.values'].create({
                #         'odoo_values': f"Total Price : <div {total_price_style}>{get_product.price_subtotal} </div>",
                #         'report_values': f"Total Price : <div {total_price_style}>{product.get('total_price', )} </div>",
                #     })
                #     compare_vals_list.append(compare_vals_total_price.id)

        return [(6, 0, compare_vals_list)]

    def update_values_to_record(self):
        if self.product_lines_update:
            # convert the list in string object to actual list object
            product_list = ast.literal_eval(self.product_lines_update)
            for l in product_list:
                if 'product_name' in l:
                    # if self.purchase_order:
                    #     get_product_line_po = self.purchase_order.order_line.filtered(
                    #         lambda p: p.product_id.name == l.get('product_name'))
                    #     if get_product_line_po:
                    #         if 'quantity' in l:
                    #             get_product_line_po.product_qty = l.get('quantity')
                    #         if 'unit_price' in l:
                    #             get_product_line_po.price_unit = l.get('unit_price')
                    #         else:
                    #             print(get_product_line_po.price_unit, 'before')
                    #             get_product_line_po.update({'price_unit': get_product_line_po.price_unit})
                    #             print(get_product_line_po.price_unit, 'price')

                    if self.stock_picking_id:
                        get_product_line_sp = self.stock_picking_id.move_ids_without_package.filtered(
                            lambda p: p.product_id.name == l.get('product_name'))
                        if get_product_line_sp:
                            if 'quantity' in l:
                                get_product_line_sp.quantity = l.get('quantity')
