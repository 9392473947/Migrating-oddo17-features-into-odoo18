from odoo import fields, models, api, _

class ProjectStotz(models.Model):
    _inherit = 'project.project'

    project_type = fields.Selection([('mech production','Mech Production'),('electronic production','Electronic production'),
                                     ('repairs','Repairs'),('service','Service')])

    project_category = fields.Selection([('big projects','Big Projects'),('small projects','Small projects'),
                                         ('repairs','Repairs'),('service','Service')])
