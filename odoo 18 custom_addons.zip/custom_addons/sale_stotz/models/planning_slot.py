from odoo import models, fields, api
import pytz


class PlanningSlot(models.Model):
    _inherit = "planning.slot"

    no_compute_allocated_hours = fields.Boolean('No Compute')
    auto_task = fields.Many2one('project.task','Task')


    @api.depends(
        'start_datetime', 'end_datetime', 'resource_id.calendar_id',
        'company_id.resource_calendar_id', 'allocated_percentage')
    def _compute_allocated_hours(self):
        for rec in self:
            if rec.no_compute_allocated_hours != True:
                return super(PlanningSlot, self)._compute_allocated_hours()
