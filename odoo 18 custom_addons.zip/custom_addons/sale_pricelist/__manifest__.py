{
    'name' : 'Sale Order Pricelist',
    'version' : '2.0',
    'author': 'Nivetha',
    'summary': 'sale order pricelist',
    'sequence': 10,
    'depends': ['base','sale','product'],
    'data': [
        'security/ir.model.access.csv',
        'views/sale_order_line_form.xml',
        'views/product_pricelist.xml',
        'views/product_material.xml',
        'views/product_channel.xml',
        'views/product_jet.xml',
        'views/product_template.xml',
        'views/product_symmetry.xml',
        'views/product_equipment.xml',
        'views/product_type.xml',

    ],


    'installable': True,

    'module_type': 'official',
    'license': 'LGPL-3'
}