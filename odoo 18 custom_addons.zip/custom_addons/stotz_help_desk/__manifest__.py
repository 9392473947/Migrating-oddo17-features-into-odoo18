{
    "name": "Help Desk Enhancement",
    "author": "PMCPL",
    "version": "0.0.1",
    "license": "LGPL-3",
    "depends": ['project','base','project_helpdesk'],
    "data": [
        # "security/crm_rule.xml",
        "views/help_desk.xml",
    ],
    "installable": True,
    "auto_install": False,
    "application": True,
}
