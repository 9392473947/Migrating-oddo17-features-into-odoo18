from odoo import models, fields, api


class ContactType(models.Model):
    _inherit = 'res.partner'

    contact_type = fields.Selection([('internal_user', 'Internal User'), ('external_user', 'External User')])

    def set_internal_user(self):
        for rec in self.env['res.partner'].search([]):
            if rec.user_ids:
                rec.contact_type = 'internal_user'


class InheritResUser(models.Model):
    _inherit = 'res.users'

    def create(self, vals_list):
        res = super(InheritResUser, self).create(vals_list)
        res.partner_id.contact_type = 'internal_user'
        return res
