from odoo import models, fields, api


class ResPartnerInherit(models.Model):
    _inherit = "res.partner"

    is_approved = fields.Boolean(default=False, copy=False)
    to_approve = fields.Boolean(default=True, copy=False)
    is_approval_compute = fields.Boolean()
    approval_state = fields.Selection([('to_approve', 'To Approve'),
                              ('approved', 'Approved'),
                              ], tracking=True, copy=False, default='to_approve')

    # def write(self, vals):
    #     print(vals,"ppppppppppppppp")
    #     if 'approval_state' not in vals:
    #         vals['approval_state']='to_approve'
    #         # i.approval_state = 'to_approve'
    #     print(vals,"oooo")
    #     res = super(ResPartnerInherit, self).write(vals)
    #
    #     return res

    # @api.constrains('function', 'phone')
    # @api.depends('function', 'phone')
    # def changing_values_need_approval(self):
    #     for rec in self:
    #         rec.approval_state = 'to_approve'

    def button_approve(self):
        if not self.approval_state or self.approval_state == 'to_approve':
            self.approval_state = 'approved'
