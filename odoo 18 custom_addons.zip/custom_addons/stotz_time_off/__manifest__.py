{
    'name': 'Time Off',
    'category': 'Time Off',
    'description': """ """,
    'depends': ['hr_holidays'],
    'data': [
        'views/time_off.xml'
    ],

    'license': 'LGPL-3',
    "application": True,
}
