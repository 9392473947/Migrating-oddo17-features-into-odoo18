{
    'name': ' Sequence for Field Service',
    'description': """ """,
    'depends': ['project','industry_fsm_sale','timesheet_grid','account'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'views/sequence.xml',
        'templates/field_service_report.xml'
    ],
    "application": True,
}
