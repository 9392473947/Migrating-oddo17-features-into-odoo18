from odoo import api, fields, models
from datetime import timedelta

from odoo.exceptions import AccessError

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import ValidationError



class PurchaseOrderInherit(models.Model):
    _inherit = 'purchase.order'



    require_confirmation_from_subcontractor = fields.Boolean(string="PO confirmed")

    is_subcontracting = fields.Boolean(string="Subcontracted product",compute="_compute_require_confirmation",store=True)

    @api.depends('product_id')
    def _compute_require_confirmation(self):
        for order in self:
            order.is_subcontracting = False  # Default to False
            for line in order.order_line:
                for route in line.product_id.route_ids:
                    if route.name == "Resupply Subcontractor on Order":
                        order.is_subcontracting = True
                        break
                if order.is_subcontracting:
                    break

    def action_check_confirmation(self):
        print("oooo")
        for record in self:
            print("dkjhg")
            record.require_confirmation_from_subcontractor = True



    @api.model_create_multi
    def send_confirmation_reminder_emails(self):

        today = fields.Date.today()
        days_to_reminder = 3
        for order in self.search([]):
            if order.subcontracting_resupply_picking_count != 0 and (today - fields.Date.to_date(order.date_order)).days == days_to_reminder and not order.require_confirmation_from_subcontractor:


                email_body = (f"Dear {order.partner_id.name},\n\n"
                              f"This is a reminder to confirm the Purchase Order {order.name}")
                email_to = order.partner_id.email
                order.send_email(email_body,email_to)

    def send_email(self, body,to):

        # Create an instance of the Mail class
        mail_obj = self.env['mail.mail']

        # Compose the email
        email_values = {
            'subject': "Reminder for purchase order confirmation",
            'body_html': body,
            'email_to': to,
        }

        # Send the email
        mail_id = mail_obj.create(email_values)
        mail_id.send()



    @api.model_create_multi
    def create(self, vals):
        current_user = self.env.user
        print("Current User:", current_user.name, "| ID:", current_user.id)
        if not self.env.user.has_group('stotz_purchase_order.purchase_order_admin'):
            raise AccessError("You are not allowed to create purchase orders.")

        return super(PurchaseOrderInherit, self).create(vals)

    def write(self, vals):

        if not self.env.user.has_group('stotz_purchase_order.purchase_order_admin'):
            raise AccessError("You are not allowed to modify purchase orders.")

        return super(PurchaseOrderInherit, self).write(vals)

    def unlink(self):
        if not self.env.user.has_group('stotz_purchase_order.purchase_order_admin'):
            raise AccessError("You are not allowed to delete purchase orders.")
        return super(PurchaseOrderInherit, self).unlink()



    # def default_get(self, fields_list):
    #     defaults = super(PurchaseOrderInherit, self).default_get(fields_list)
    #     print(fields_list)
    #     if 'reminder_date_before_receipt' in fields_list:
    #
    #         defaults['reminder_date_before_receipt'] = 7
    #
    #     return defaults


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order'

    def action_rfq_send(self):
        for order in self:
            for line in order.order_line:
                # Check if the product has a vendor associated with the order's vendor
                supplier_info = line.product_id._select_seller(
                    partner_id=order.partner_id,
                    quantity=line.product_qty,
                    date=order.date_order and order.date_order.date(),
                    uom_id=line.product_uom)

                # If no supplier info is found, raise an error
                if not supplier_info:
                    raise ValidationError(
                        'No pricelist available for product %s from vendor %s.' % (
                        line.product_id.display_name, order.partner_id.display_name))

                # Check if the entered price matches the price in the vendor's pricelist
                if line.price_unit != supplier_info.price:
                    raise ValidationError(
                        'The price for product %s must match the vendor price list (%s). Entered price: %s, Vendor price: %s' % (
                            line.product_id.display_name, order.partner_id.display_name, line.price_unit,
                            supplier_info.price))

        return super(PurchaseOrderLine, self).action_rfq_send()

    # def action_rfq_send(self):
    #     for order in self:
    #         for line in order.order_line:
    #             if line.price_unit <= 0.0:
    #                 raise ValidationError('Price is required and must be greater than zero.')
    #     return super(PurchaseOrderLine, self).action_rfq_send()