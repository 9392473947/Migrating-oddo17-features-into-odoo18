from odoo import models, fields


class ProjectTemplateSelect(models.TransientModel):
    _name = 'project.template.select'

    name = fields.Char('Project Name', required=True)
    project_template_id = fields.Many2one('project.project', required=True)

    def create_copy_new(self):
        for rec in self:
            project = rec.project_template_id.copy({'name': rec.name})
            for task in project.task_ids:
                task.user_ids = False
