{
    'name' : 'Purchase order stotz',
    'version' : '2.0',
    'author': 'Nivetha',
    'summary': 'purchase order scheduled activity',
    'sequence': 10,
    'depends': ['purchase','base','mrp','mrp_subcontracting_purchase','stock','mail','sms','web','uom'],
    'data': [
        'data/cron.xml',
        'data/po_cron.xml',


        'security/security.xml',
        'views/res_partner_form_view.xml',
        'views/po_vendor_specific_view.xml',
        'views/remove_matrix_po.xml',
        'views/purchase_order.xml',

    ],


    'installable': True,

    'module_type': 'official',
    'license': 'LGPL-3'
}