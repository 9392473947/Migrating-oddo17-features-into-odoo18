from odoo import models, fields, api, tools


class MailThreadInherit(models.AbstractModel):
    _inherit = 'mail.thread'

    @api.model
    def _message_route_process(self, message, message_dict, routes):
        self = self.with_context(attachments_mime_plainxml=True)  # import XML attachments as text
        # postpone setting message_dict.partner_ids after message_post, to avoid double notifications
        original_partner_ids = message_dict.pop('partner_ids', [])
        thread_id = False
        for model, thread_id, custom_values, user_id, alias in routes or ():
            subtype_id = False
            related_user = self.env['res.users'].browse(user_id)
            Model = self.env[model].with_context(mail_create_nosubscribe=True, mail_create_nolog=True)
            if not (thread_id and hasattr(Model, 'message_update') or hasattr(Model, 'message_new')):
                raise ValueError(
                    "Undeliverable mail with Message-Id %s, model %s does not accept incoming emails" %
                    (message_dict['message_id'], model)
                )

            # disabled subscriptions during message_new/update to avoid having the system user running the
            # email gateway become a follower of all inbound messages
            ModelCtx = Model.with_user(related_user).sudo()
            if thread_id and hasattr(ModelCtx, 'message_update'):
                thread = ModelCtx.browse(thread_id)
                thread.message_update(message_dict)
            else:
                # if a new thread is created, parent is irrelevant
                message_dict.pop('parent_id', None)
                # Report failure/record success of message creation except if alias is not defined (fallback model case)
                try:
                    thread = ModelCtx.message_new(message_dict, custom_values)
                except Exception:
                    if alias:
                        with self.pool.cursor() as new_cr:
                            self.with_env(self.env(cr=new_cr)).env['mail.alias'].browse(alias.id
                                                                                        )._alias_bounce_incoming_email(
                                message, message_dict, set_invalid=True)
                    raise
                else:
                    if alias and alias.alias_status != 'valid':
                        alias.alias_status = 'valid'
                thread_id = thread.id
                subtype_id = thread._creation_subtype().id

            # switch to odoobot for all incoming message creation
            # to have a priviledged archived user so real_author_id is correctly computed
            thread_root = thread.with_user(self.env.ref('base.user_root'))
            # replies to internal message are considered as notes, but parent message
            # author is added in recipients to ensure they are notified of a private answer
            parent_message = False
            if message_dict.get('parent_id'):
                parent_message = self.env['mail.message'].sudo().browse(message_dict['parent_id'])
            partner_ids = []
            if not subtype_id:
                if message_dict.get('is_internal'):
                    subtype_id = self.env['ir.model.data']._xmlid_to_res_id('mail.mt_note')
                    if parent_message and parent_message.author_id:
                        partner_ids = [parent_message.author_id.id]
                else:
                    subtype_id = self.env['ir.model.data']._xmlid_to_res_id('mail.mt_comment')

            post_params = dict(subtype_id=subtype_id, partner_ids=partner_ids, **message_dict)
            # remove computational values not stored on mail.message and avoid warnings when creating it
            for x in ('from', 'to', 'cc', 'recipients', 'references', 'in_reply_to', 'is_bounce', 'bounced_email',
                      'bounced_message', 'bounced_msg_ids', 'bounced_partner'):
                post_params.pop(x, None)
            new_msg = False
            if thread_root._name == 'mail.thread':  # message with parent_id not linked to record
                new_msg = thread_root.message_notify(**post_params)
            else:
                # parsing should find an author independently of user running mail gateway, and ensure it is not odoobot
                partner_from_found = message_dict.get('author_id') and message_dict['author_id'] != self.env[
                    'ir.model.data']._xmlid_to_res_id('base.partner_root')
                thread_root = thread_root.with_context(from_alias=True, mail_create_nosubscribe=not partner_from_found)
                new_msg = thread_root.message_post(**post_params)
                # custom code for cc while reply to mail
                update_cc_email = tools.decode_message_header(message, 'cc', separator=',')
                cc_formate = tools.email_split_and_format(update_cc_email)
                cust_email_cc = []
                for ccs in cc_formate:
                    if '<' in ccs:
                        sp = ccs.split('<')
                        if sp:
                            sp1 = sp[1].split('>')
                            cust_email_cc.append(sp1[0])
                    else:
                        cust_email_cc.append(ccs)
                if cust_email_cc:
                    new_msg.update({
                        'cc_email': ','.join(cust_email_cc)
                    })
                if model == 'crm.lead':
                    update_ccs = self.env[model].browse(thread_id)
                    update_ccs.update({
                        'recent_cc': ','.join(cust_email_cc)
                    })

                # print(message_dict, 'message_dictmessage_dictmessage_dictmessage_dict')
                # bcc_email = tools.decode_message_header(message, 'bcc', separator=',')
                # bcc_formate = tools.email_split_and_format(bcc_email)
                # cust_email_bcc = []
                # for ccs in bcc_formate:
                #     sp = ccs.split('<')
                #     sp1 = sp[1].split('>')
                #     cust_email_bcc.append(sp1[0])
                # if cust_email_bcc:
                #     new_msg.update({
                #         'bcc_email': ','.join(cust_email_bcc)
                #     })
            if new_msg and original_partner_ids:
                # postponed after message_post, because this is an external message and we don't want to create
                # duplicate emails due to notifications
                new_msg.write({'partner_ids': original_partner_ids})
        return thread_id
