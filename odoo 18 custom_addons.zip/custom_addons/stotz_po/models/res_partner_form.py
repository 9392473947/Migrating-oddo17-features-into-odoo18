from odoo import fields,models,api,_
from odoo.exceptions import ValidationError,UserError
import xlrd
import base64



class ResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    need_confirmation_for_po = fields.Boolean(string="PO Confirmation Needed ?")


