from odoo import models, fields, api


class WorksheetTemplate(models.Model):
    _inherit = 'worksheet.template'

    works = fields.Text('Works')
    opl = fields.Boolean('OPL (See sheet 2)')
    stotz_time = fields.Integer('Stotz Time')
    guarantee_accomodation = fields.Boolean('Guarantee/Accomodation')
    chargeable = fields.Boolean('Chargeable')
    remarks = fields.Text('Remarks')
    an = fields.Char('An')
    ke = fields.Char('KE')
    km = fields.Char('Km')
    pl = fields.Char('PL')
    travelling_description = fields.Text('Travelling Description')
    mach_work = fields.Boolean('Mach. Works')
    add_visit_neccessary = fields.Boolean('Add. Visit Necessary')
    mission_completed = fields.Boolean('Mission Completed')
    date = fields.Date('Date')
    talk_to = fields.Many2one('res.partner')
