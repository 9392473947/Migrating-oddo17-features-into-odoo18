from odoo import models, fields, _
from openai import OpenAI, NotFoundError, RateLimitError
from odoo.exceptions import ValidationError, UserError


class OCRResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    openai_api = fields.Char('API', config_parameter='ocr_pdf_comparing.openai_api')

    def check_openAI_api(self):
        get_api_key = self.env['ir.config_parameter'].sudo().get_param('ocr_pdf_comparing.openai_api')
        if not get_api_key:
            raise ValidationError('Please add the Api key in setting.')
        client = OpenAI(api_key=get_api_key)
        try:
            completion = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": "HI."}
                ]
            )
            if completion:
                message = _("API Test Successful!")
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'message': message,
                        'type': 'success',
                        'sticky': False,
                    }
                }
        except NotFoundError as e:
            error_message = e.message
            if 'you do not have access to it' in error_message:
                raise UserError('User do not have access to it.')
            else:
                raise UserError(error_message)
        except RateLimitError as e:
            error_message = e.message
            if 'exceeded your current quota' in error_message:
                raise UserError('You exceeded your current quota, please check your plan and billing details.')
            else:
                raise UserError(error_message)
        except Exception as e:
            raise UserError(e)
